module.exports = {
  BOT_TOKEN: "https://whatsapp.com/channel/0029Vb2E8NH4SpkD9oqVTo0d",//MASUKIN TOKEN BOT BISA AMBIL DARI @BotFather
  OWNER_ID: ["https://whatsapp.com/channel/0029Vb2E8NH4SpkD9oqVTo0d"],//MASUKIN ID TELE LU BUAT LIAT ID TELE KE @Rose KETIK CMD /info
};