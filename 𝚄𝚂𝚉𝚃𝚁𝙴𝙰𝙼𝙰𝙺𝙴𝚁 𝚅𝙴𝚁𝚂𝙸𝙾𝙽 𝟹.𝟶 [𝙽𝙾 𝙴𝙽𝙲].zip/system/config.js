//========usztreamaker========

global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.namaCreator = '𝚄𝚂𝚉𝙿𝚁𝙾'
global.owner = ["6283194962608"]
global.namabot = '𝚄𝚂𝚉-𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁'
global.isLink = 'https://www.youtube.com/@usz-treamaker'
global.imageurl = 'https://l.top4top.io/p_3447pnov51.jpg'

//=======================

global.mess = { 
owner: '𝙺𝙰𝙼𝚄 𝙱𝚄𝙺𝙰𝙽 𝙾𝚆𝙽𝙴𝚁!',
premium: '𝙺𝙰𝙼𝚄 𝙱𝚄𝙺𝙰𝙽 𝙼𝙴𝙼𝙱𝙴𝚁 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 𝙱𝙰𝙽𝙶 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁🤭',
succes: '𝙳𝙾𝙽𝙴 𝙱𝙽𝙶 𝚄𝚂𝚉𝚃𝚁𝙴𝙰𝙼𝙰𝙺𝙴𝚁💥'
}