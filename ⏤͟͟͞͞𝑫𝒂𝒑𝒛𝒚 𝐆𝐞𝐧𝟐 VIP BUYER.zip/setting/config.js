const fs = require('fs')

global.owner = "6283898748329" //owner number
global.footer = "𝑫𝒂𝒑𝒛𝒚" //footer section
global.namabot = "𝑫𝒂𝒑𝒛𝒚" //nama bot
global.status = true //"self/public" section of the bot
global.namaowner = "𝑫𝒂𝒑𝒛𝒚"
global.idsaluran = "-"
global.imgmenu = "https://img1.pixhost.to/images/6306/608152059_lexcz.jpg"

//======[ Setting Event ]======//
global.dana = `08973907614`
global.gopay = `08973907614`
global.ovo = "-"
global.shope = "-"
global.bank = "-"
global.qris = fs.readFileSync("./media/qris.jpg")
global.namastore = "*Dapzy Developer*"
global.lol = "";
global.msg = {
    owner: "You Are Not Owner",
    premium: "You Are Not Premium Member",
    admin: "You Are Not Admin",
    adminbot: "Me Not Admin",
    priv: "khusus pribadi",
    bot: "khusus nomer bot"
}
global.autoTyping = false // ubah jadi true untuk menyalakan auto typing

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
