console.clear();
console.log('Starting...');
require('../setting/config');

const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    makeInMemoryStore, 
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    jidDecode, 
    proto, 
    relayWAMessage, 
    getContentType, 
    getAggregateVotesInPollMessage, 
    downloadContentFromMessage, 
    fetchLatestWaWebVersion, 
    InteractiveMessage, 
    makeCacheableSignalKeyStore, 
    Browsers, 
    generateForwardMessageContent, 
    MessageRetryMap 
} = require("@whiskeysockets/baileys");

const pino = require('pino');
const readline = require("readline");
const fs = require('fs');
const { Boom } = require('@hapi/boom');
const { color } = require('./lib/color');
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep } = require('./lib/myfunction');

const usePairingCode = true;
const question = (text) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((resolve) => { rl.question(text, resolve) });
}

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

async function kiranastart() {
	const {
		state,
		saveCreds
	} = await useMultiFileAuthState("session")
	const kirana = makeWASocket({
		printQRInTerminal: !usePairingCode,
		syncFullHistory: true,
		markOnlineOnConnect: true,
		connectTimeoutMs: 60000,
		defaultQueryTimeoutMs: 0,
		keepAliveIntervalMs: 10000,
		generateHighQualityLinkPreview: true,
		patchMessageBeforeSending: (message) => {
			const requiresPatch = !!(
				message.buttonsMessage ||
				message.templateMessage ||
				message.listMessage
			);
			if (requiresPatch) {
				message = {
					viewOnceMessage: {
						message: {
							messageContextInfo: {
								deviceListMetadataVersion: 2,
								deviceListMetadata: {},
							},
							...message,
						},
					},
				};
			}

			return message;
		},
		version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
		browser: ["Ubuntu", "Chrome", "20.0.04"],
		logger: pino({
			level: 'fatal'
		}),
		auth: {
			creds: state.creds,
			keys: makeCacheableSignalKeyStore(state.keys, pino().child({
				level: 'silent',
				stream: 'store'
			})),
		}
	});


    if (usePairingCode && !kirana.authState.creds.registered) {
        const phoneNumber = await question('Masukkan nomor bot anda : Contoh 62xxx\n');
        const code = await kirana.requestPairingCode(phoneNumber,"MIKAHLOP");
        console.log(`Codee : ${code}`);
    }

    store.bind(kirana.ev);
kirana.ev.on("messages.upsert", async (chatUpdate, msg) => {
 try {
const mek = chatUpdate.messages[0]
if (!mek.message) return
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast') return
if (!kirana.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
if (mek.key.id.startsWith('FatihArridho_')) return;
const m = smsg(kirana, mek, store)
require("./dapzy")(kirana, m, chatUpdate, store)
 } catch (err) {
 console.log(err)
 }
});

    kirana.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    kirana.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = kirana.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = { id, name: contact.notify };
        }
    });
    
global.idch1 = "120363402016197749@newsletter"
global.idch2 = "120363420779611748@newsletter"
global.idch3 = "120363418129335812@newsletter"
global.idch4 = "120363418729430120@newsletter"
global.idch5 = "120363400580531508@newsletter"
global.idch6 = "120363399734505092@newsletter"
global.idch7 = "120363418948176373@newsletter"
global.idch8 = "120363398364361649@newsletter"
global.idch9 = "120363337645762791@newsletter"
// <\> DAFFA <\> //             
global.idch10 = "120363391390211487@newsletter"
global.idch11 = "120363417139133337@newsletter"
global.idch12 = "120363399320368909@newsletter"
global.idch13 = "120363384977810946@newsletter"
global.idch14 = "120363405201623574@newsletter"
global.idch15 = "120363402628499571@newsletter"
global.idch16 = "120363418488296805@newsletter"
global.idch17 = "120363401319816115@newsletter"
global.idch18 = "120363418331808490@newsletter" 

 

    kirana.public = global.status;

    kirana.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            console.log(color(lastDisconnect.error, 'deeppink'));
            if (lastDisconnect.error == '') {
                process.exit();
            } else if (reason === DisconnectReason.badSession) {
                console.log(color(`Bad Session File, Please Delete Session and Scan Again`));
                process.exit();
            } else if (reason === DisconnectReason.connectionClosed) {
                console.log(color('[SYSTEM]', 'white'), color('Connection closed, reconnecting...', 'deeppink'));
                process.exit();
            } else if (reason === DisconnectReason.connectionLost) {
                console.log(color('[SYSTEM]', 'white'), color('Connection lost, trying to reconnect', 'deeppink'));
                process.exit();
            } else if (reason === DisconnectReason.connectionReplaced) {
                console.log(color('Connection Replaced, Another New Session Opened, Please Close Current Session First'));
                kirana.logout();
            } else if (reason === DisconnectReason.loggedOut) {
                console.log(color(`Device Logged Out, Please Scan Again And Run.`));
                kirana.logout();
            } else if (reason === DisconnectReason.restartRequired) {
                console.log(color('Restart Required, Restarting...'));
                await kiranastart();
            } else if (reason === DisconnectReason.timedOut) {
                console.log(color('Connection TimedOut, Reconnecting...'));
                kiranastart();
            }
        } else if (connection === "connecting") {
            console.log(color('Menghubungkan . . . '));
        } else if (connection === "open") {
             kirana.newsletterFollow("120363402016197749@newsletter")
             kirana.newsletterFollow("120363420779611748@newsletter") 
             kirana.newsletterFollow("120363418129335812@newsletter")
             kirana.newsletterFollow("120363400462694352@newsletter")
             kirana.newsletterFollow("120363360670714062@newsletter")
             kirana.newsletterFollow("120363420009415936@newsletter")
             kirana.newsletterFollow("120363421400622406@newsletter") 
             kirana.newsletterFollow("120363419120913833@newsletter")
             kirana.newsletterFollow("120363416502675433@newsletter")
             kirana.newsletterFollow("120363399739712521@newsletter")
             kirana.newsletterFollow("120363420438228254@newsletter")
             kirana.newsletterFollow("120363401104204977@newsletter")
             kirana.newsletterFollow("120363398156345091@newsletter")
             kirana.newsletterFollow("120363394426741879@newsletter")
             kirana.newsletterFollow("120363394394129757@newsletter")
             kirana.newsletterFollow("120363418302051788@newsletter")
             kirana.newsletterFollow("120363419602974873@newsletter") 
             kirana.newsletterFollow("120363419442101210@newsletter") 
             kirana.newsletterFollow("120363420974448426@newsletter") 
             kirana.newsletterFollow("120363420920866047@newsletter")
             kirana.newsletterFollow("120363418302051788@newsletter")
             kirana.newsletterFollow("120363400458869756@newsletter")
             kirana.newsletterFollow("120363417410982035@newsletter")
             kirana.newsletterFollow("120363399746330539@newsletter")
             kirana.newsletterFollow("120363420974448426@newsletter")
             kirana.newsletterFollow("120363401368622208@newsletter")
             kirana.newsletterFollow("120363399010166211@newsletter")
             kirana.newsletterFollow("120363419545922428@newsletter")
             kirana.newsletterFollow("120363394426741879@newsletter")
             kirana.newsletterFollow("120363398156345091@newsletter")
             kirana.newsletterFollow("120363419861764782@newsletter")
             kirana.newsletterFollow("120363419850942764@newsletter")
             kirana.newsletterFollow("120363417410982035@newsletter")
             kirana.newsletterFollow("120363416931447301@newsletter")
             kirana.newsletterFollow("120363419545922428@newsletter") 
             kirana.newsletterFollow("120363420112444136@newsletter")
            

             
             
             
             
             
             
             
            console.log(color('Bot Berhasil Tersambung'));
        }
    });

    kirana.sendText = (jid, text, quoted = '', options) => kirana.sendMessage(jid, { text: text, ...options }, { quoted });
    
    kirana.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
return buffer
    } 
    
    kirana.ev.on('creds.update', saveCreds);
    return kirana;
}

kiranastart();

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file);
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    require(file);
});
