//========HELO FRIEND========//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6283173945701"] 
global.namabot = 'ZeroCrash 𝖵4 𝖵𝖨𝖯'
//======================
global.mess = { 
owner: '*𝖫𝖴 𝖲𝖨𝖠𝖯𝖠 𝖭𝖩𝖨𝖱? 𝖫𝖴 𝖡𝖴𝖪𝖠𝖭 𝖡𝖠𝖭𝖦 ZEROCZY*',
premium: '*𝖫𝖴 𝖡𝖴𝖪𝖠𝖭 𝖴𝖲𝖤𝖱𝖲 𝖯𝖱𝖤𝖬𝖨𝖴𝖬 𝖠𝖭𝖩*',
succes: '*𝖣𝖮𝖭𝖤 𝖡𝖸 𝖡𝖠𝖭𝖦 ZERO 𝖦𝖠𝖭𝖳𝖤𝖭𝖦*'
}
//======================