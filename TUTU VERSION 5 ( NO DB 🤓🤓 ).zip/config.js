module.exports = {
    BOT_TOKEN: "TOKENS", // Replace with your Telegram bot token
    OWNER_IDS: [
        "IDS"
    ],
    // TUTU AMPAS TOLOL
};