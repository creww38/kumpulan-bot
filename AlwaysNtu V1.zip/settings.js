const fs = require('fs')

// >~~~~~~~~~~ Owner Setting ~~~~~~~~~~~< //
global.owner = "6285355458766"
global.ownername = "͟͟͞͞𝙓𝙕𝙔𝙏 | 𝘼𝙇𝙒𝘼𝙔𝙎𝙉𝙏𝙐🜲"
global.botname = "𝗔𝗟𝗪𝗔𝗬𝗦𝗡𝗧𝗨 𝗕𝗢𝗧𝗭"
global.footer = "ALWAYSNTU KASEP"
global.packname = "ZYLEN JELEK"

// >~~~~~~~~~~ System Setting ~~~~~~~~~~~< //
global.version = "1.0.0"
global.idch = "120363404820874313@newsletter"
global.prefa = ["", "/"]
global.link = 'https://whatsapp.com/channel/0029VacUGcxDJuiseBDW0h'

// >~~~~~~~~~~ Thumbnail Setting ~~~~~~~~~~~< //
global.thumb = "https://files.catbox.moe/l0ikwl.jpg"

global.image = {
menu: "https://files.catbox.moe/v4aylc.jpg", 
reply: "https://files.catbox.moe/3k2a0s.jpg", 
logo: "https://files.catbox.moe/3k2a0s.jpg", 
bugmenu: "https://files.catbox.moe/6kjtpl.jpg",
qris: ""
}
// >~~~~~~~~~~ Message Setting ~~~~~~~~~~~< //
global.mess = {
owner: "-[ *AKSES DITOLAK* ]-\n> *_Anda Tidak Dapat Menggunakan Fitur Ini Karena Anda Bukanlah Owner!_*", 
ownerprem: "-[ *AKSES DITOLAK* ]-\n> *_Anda Tidak Dapat Menggunakan Fitur Ini Karena Anda Bukanlah Owner & User Premium!_*"
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
