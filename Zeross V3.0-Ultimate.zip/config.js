module.exports = {
  BOT_TOKEN: "ISI_TOKEN",
  OWNER_ID: ["7250235697"],
};