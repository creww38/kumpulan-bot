module.exports = {
  BOT_TOKEN: "https://whatsapp.com/channel/0029Vb2E8NH4SpkD9oqVTo0d",
  OWNER_ID: ["6484803509"],
};