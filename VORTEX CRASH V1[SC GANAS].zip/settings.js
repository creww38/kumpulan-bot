const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.ch = 'https://whatsapp.com/channel/0029Vb4xNCE5q08dRIMzC11K'
global.status = true
//====== [ THEME URL & URL ] ========//
global.thumb = "https://img1.pixhost.to/images/6572/612301017_rizzhosting.jpg"
global.thumbnail = "https://img1.pixhost.to/images/6572/612301017_rizzhosting.jpg"
//====== [ MESSAGE SETTINGS ] ========//
global.packname = '𓆩۞𓆪'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})