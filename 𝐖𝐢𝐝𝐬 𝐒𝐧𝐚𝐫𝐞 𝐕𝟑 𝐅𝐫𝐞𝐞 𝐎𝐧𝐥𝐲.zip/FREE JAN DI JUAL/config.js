module.exports = {
  BOT_TOKEN: "Token_Lu_",
  OWNER_ID: ["id"],
};