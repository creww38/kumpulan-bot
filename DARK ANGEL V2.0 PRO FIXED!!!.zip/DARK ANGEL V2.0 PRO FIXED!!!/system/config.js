//========HELO FRIEND========//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6282225336423"] 
global.namabot = 'ler sanzy'
//======================
global.mess = { 
owner: '*waduhh!, lu bukan owner gw bg*',
premium: '*anda bukan user premium*',
succes: '*done bang*'
}
//======================