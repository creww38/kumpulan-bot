require("./lib/module.js")

// ===== !! Setting Bot & Owner !! ===== \\
global.owner = "6285742698411"
global.BotName = "Zxent V3" 
global.OwnerName = "Manzx Mods"
global.packname = "Create By"
global.author = "Manzx Mods"

// ===== !! Setting Url !! ===== \\
global.thumbUrl = "https://files.catbox.moe/s20gza.jpeg" //buat sendiri di web tu
global.LinkCh = "https://whatsapp.com/channel/"
global.IDch = "120363334353222571@newsletter"


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})