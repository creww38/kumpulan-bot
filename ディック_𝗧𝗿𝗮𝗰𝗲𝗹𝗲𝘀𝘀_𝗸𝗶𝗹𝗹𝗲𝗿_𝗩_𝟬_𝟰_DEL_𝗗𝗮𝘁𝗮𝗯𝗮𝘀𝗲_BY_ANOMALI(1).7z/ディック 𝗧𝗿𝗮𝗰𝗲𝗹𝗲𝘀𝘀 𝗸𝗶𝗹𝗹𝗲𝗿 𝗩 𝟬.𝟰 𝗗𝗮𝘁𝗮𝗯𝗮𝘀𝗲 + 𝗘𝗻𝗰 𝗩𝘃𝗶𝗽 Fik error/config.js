module.exports = {
  BOT_TOKEN: "7871174643:AAEANrtZVea8WOjk-yqgzuwKeojS08H4aLU",
  OWNER_ID: ["6454570447"],
};
